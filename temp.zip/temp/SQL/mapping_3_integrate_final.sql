/* ------------------------------------------------------------------------------
   PROJET      : INEO
   APPLICATION : MIG_V5
   OBJET       : Int�gration des donn�es TMP vers la table finale
   AUTEUR      : UFLULY
   DATE        : 03/03/2026
   ------------------------------------------------------------------------------ */

SET NOCOUNT ON;

-- Purge compl�te de la table finale avant r�int�gration
TRUNCATE TABLE dbo.ORT_PARAM_COMPARAISON_V4_V5;

-- Int�gration simple des donn�es apr�s contr�le (sans cl�s fonctionnelles)
INSERT INTO dbo.ORT_PARAM_COMPARAISON_V4_V5
(
    NOM_TABLE_V5,
    NOM_COLONNE_V5,
    NOM_TABLE_V4,
    NOM_COLONNE_V4,
    FLAG_CLEFONC,
    REGLE_TRANSFORMATION_V4
)
SELECT
    NOM_TABLE_V5,
    NOM_COLONNE_V5,
    NOM_TABLE_V4,
    NOM_COLONNE_V4,
    FLAG_CLEFONC,
    REGLE_TRANSFORMATION_V4
FROM dbo.ORT_PARAM_COMPARAISON_V4_V5_TMP;