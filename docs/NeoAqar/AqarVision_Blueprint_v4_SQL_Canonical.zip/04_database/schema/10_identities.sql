create table users (
  id uuid primary key,
  created_at timestamptz not null default now()
);

create table profiles (
  user_id uuid primary key references users(id) on delete cascade,
  full_name text,
  avatar_url text,
  phone text,
  role user_role not null default 'end_user',
  preferred_locale text not null default 'fr' check (preferred_locale in ('fr','ar','en','es')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table mobile_devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  platform text not null,
  app_version text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  last_seen_at timestamptz
);

create table push_tokens (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  mobile_device_id uuid references mobile_devices(id) on delete cascade,
  token text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
