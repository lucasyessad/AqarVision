create table plans (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  is_active boolean not null default true,
  max_listings integer,
  max_ai_jobs integer,
  created_at timestamptz not null default now()
);

create table subscriptions (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  plan_id uuid not null references plans(id),
  status subscription_status not null,
  started_at timestamptz,
  ended_at timestamptz,
  created_at timestamptz not null default now()
);

create table ai_prompts (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  version text not null,
  system_prompt text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table ai_jobs (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  listing_id uuid references listings(id) on delete cascade,
  prompt_id uuid references ai_prompts(id),
  source_locale text,
  target_locale text,
  status text not null,
  input_payload jsonb not null,
  output_payload jsonb,
  cost_estimated numeric(12,6),
  created_at timestamptz not null default now()
);

create table agency_feature_entitlements (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  feature_code text not null,
  is_enabled boolean not null default false,
  created_at timestamptz not null default now(),
  unique(agency_id, feature_code)
);

create table domain_events (
  id uuid primary key default gen_random_uuid(),
  aggregate_type text not null,
  aggregate_id uuid not null,
  event_name text not null,
  agency_id uuid references agencies(id) on delete set null,
  actor_user_id uuid references users(id) on delete set null,
  payload jsonb not null,
  created_at timestamptz not null default now(),
  processed_at timestamptz
);

create table listing_views (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  viewer_user_id uuid references users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table agency_stats_daily (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  day date not null,
  total_views integer not null default 0,
  total_leads integer not null default 0,
  total_new_listings integer not null default 0,
  unique(agency_id, day)
);

create table audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_user_id uuid references users(id) on delete set null,
  agency_id uuid references agencies(id) on delete set null,
  entity_type text not null,
  entity_id uuid,
  action text not null,
  before_payload jsonb,
  after_payload jsonb,
  created_at timestamptz not null default now()
);
