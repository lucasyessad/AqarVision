create index idx_agency_branches_agency_id on agency_branches(agency_id);
create index idx_agency_memberships_agency_id on agency_memberships(agency_id);
create index idx_agency_memberships_user_id on agency_memberships(user_id);

create index idx_listings_agency_id on listings(agency_id);
create index idx_listings_branch_id on listings(branch_id);
create index idx_listings_status on listings(current_status);
create index idx_listings_listing_type on listings(listing_type);
create index idx_listings_property_type on listings(property_type);
create index idx_listings_wilaya_code on listings(wilaya_code);
create index idx_listings_published_at on listings(published_at desc);
create index idx_listings_location_gist on listings using gist(location);

create index idx_listing_translations_listing_locale on listing_translations(listing_id, locale);
create index idx_listing_media_listing_id on listing_media(listing_id);
create index idx_listing_documents_listing_id on listing_documents(listing_id);

create index idx_favorites_user_id on favorites(user_id);
create index idx_notes_user_id on notes(user_id);
create index idx_saved_searches_user_id on saved_searches(user_id);
create index idx_view_history_user_id on view_history(user_id);

create index idx_leads_agency_id on leads(agency_id);
create index idx_leads_listing_id on leads(listing_id);
create index idx_conversations_lead_id on conversations(lead_id);
create index idx_messages_conversation_id on messages(conversation_id);

create index idx_subscriptions_agency_id on subscriptions(agency_id);
create index idx_ai_jobs_agency_id on ai_jobs(agency_id);
create index idx_domain_events_unprocessed on domain_events(created_at) where processed_at is null;
create index idx_audit_logs_agency_id on audit_logs(agency_id);
