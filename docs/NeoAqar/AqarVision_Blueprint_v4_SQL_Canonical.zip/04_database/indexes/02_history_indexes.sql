create unique index idx_listing_price_versions_current
  on listing_price_versions(listing_id) where is_current = true;

create unique index idx_listing_status_versions_current
  on listing_status_versions(listing_id) where is_current = true;

create index idx_listing_price_versions_listing_valid_from
  on listing_price_versions(listing_id, valid_from desc);

create index idx_listing_status_versions_listing_valid_from
  on listing_status_versions(listing_id, valid_from desc);

create index idx_listing_revisions_listing_revision
  on listing_revisions(listing_id, revision_number desc);

create index idx_listing_publication_history_listing_id
  on listing_publication_history(listing_id);

create index idx_listing_media_history_listing_id
  on listing_media_history(listing_id);

create index idx_listing_moderation_history_listing_id
  on listing_moderation_history(listing_id);
