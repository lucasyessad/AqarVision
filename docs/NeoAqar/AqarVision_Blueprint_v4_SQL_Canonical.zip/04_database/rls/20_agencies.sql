alter table agencies enable row level security;
alter table agency_branches enable row level security;
alter table agency_memberships enable row level security;
alter table agency_invites enable row level security;

-- agencies_select_member
-- using (is_agency_member(auth.uid(), id))

-- agency_branches_select_member
-- using (is_agency_member(auth.uid(), agency_id))

-- agency_memberships_select_member
-- using (is_agency_member(auth.uid(), agency_id))
