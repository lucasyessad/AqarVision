alter table listings enable row level security;
alter table listing_translations enable row level security;
alter table listing_media enable row level security;
alter table listing_documents enable row level security;

-- listings_select_public
-- using (current_status = 'published')

-- listings_select_member
-- using (is_agency_member(auth.uid(), agency_id))

-- listings_modify_member
-- using (is_agency_member(auth.uid(), agency_id))
-- with check (is_agency_member(auth.uid(), agency_id))
