# RLS Strategy

## Règle générale
Deny by default.
Autoriser explicitement chaque cas légitime.

## Catégories
- public
- authenticated end user
- agency member
- agency admin
- super admin

## Tables sensibles
Toutes les tables métier et privées doivent être RLS-enabled.
