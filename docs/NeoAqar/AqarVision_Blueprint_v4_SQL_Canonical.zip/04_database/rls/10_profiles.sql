alter table profiles enable row level security;

-- profiles_select_self
-- using (user_id = auth.uid())

-- profiles_update_self
-- using (user_id = auth.uid())
-- with check (user_id = auth.uid())
