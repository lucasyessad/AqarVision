alter table subscriptions enable row level security;
alter table ai_jobs enable row level security;
alter table domain_events enable row level security;
alter table audit_logs enable row level security;

-- subscriptions_admin_only
-- using (exists (
--   select 1 from agency_memberships am
--   where am.user_id = auth.uid()
--     and am.agency_id = subscriptions.agency_id
--     and am.role in ('owner','admin')
-- ))
