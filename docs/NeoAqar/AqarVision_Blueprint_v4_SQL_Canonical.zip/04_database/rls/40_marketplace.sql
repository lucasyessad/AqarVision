alter table favorites enable row level security;
alter table notes enable row level security;
alter table saved_searches enable row level security;
alter table view_history enable row level security;
alter table leads enable row level security;
alter table conversations enable row level security;
alter table messages enable row level security;

-- favorites_self
-- using (user_id = auth.uid())
-- with check (user_id = auth.uid())

-- notes_self
-- using (user_id = auth.uid())
-- with check (user_id = auth.uid())

-- leads_agency_member
-- using (is_agency_member(auth.uid(), agency_id))
