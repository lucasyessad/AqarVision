-- Fonctions helpers conceptuelles

-- is_agency_member(_user_id uuid, _agency_id uuid) returns boolean
-- is_agency_admin(_user_id uuid, _agency_id uuid) returns boolean

-- Exemple logique :
-- returns exists (
--   select 1
--   from agency_memberships am
--   where am.user_id = _user_id
--     and am.agency_id = _agency_id
--     and am.is_active = true
-- );
