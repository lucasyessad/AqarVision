# Profile Bootstrap Trigger

À la création d'un user auth :
- créer automatiquement un profile
- locale par défaut = fr
- role = end_user
