# History Triggers

## Prix
Quand listings.current_price change :
1. clôturer l'ancienne ligne current dans listing_price_versions
2. créer la nouvelle ligne current
3. créer domain_event price_changed
4. créer audit log

## Statut
Quand listings.current_status change :
1. clôturer l'ancienne ligne current dans listing_status_versions
2. créer la nouvelle ligne current
3. créer domain_event status_changed
4. créer audit log
