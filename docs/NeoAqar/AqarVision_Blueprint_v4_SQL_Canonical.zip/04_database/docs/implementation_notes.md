# Implementation Notes

## Priorité
1. extensions
2. enums
3. core tables
4. history
5. indexes
6. functions
7. triggers
8. RLS

## Discipline
- ne pas coder de SQL dispersé
- documenter chaque ajout
- tester les changements de prix/statut
- tester RLS par rôle
