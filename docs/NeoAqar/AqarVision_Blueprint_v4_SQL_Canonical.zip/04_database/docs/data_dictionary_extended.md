# Data Dictionary — extended

## listings
Etat courant du bien.
Colonnes critiques :
- current_status
- current_price
- details
- location

## listing_translations
Contenu localisé du bien.
Une ligne par locale : fr, ar, en, es.

## listing_price_versions
Historique temporel SCD2 du prix.

## listing_status_versions
Historique temporel SCD2 du statut.

## domain_events
Événements produits pour analytics / future réplication warehouse.

## audit_logs
Journal de sécurité / conformité.
