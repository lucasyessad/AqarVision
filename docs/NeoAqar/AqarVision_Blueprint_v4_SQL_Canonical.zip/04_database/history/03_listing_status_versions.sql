create table listing_status_versions (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  status listing_status not null,
  valid_from timestamptz not null,
  valid_to timestamptz,
  is_current boolean not null default true,
  changed_by_user_id uuid references users(id) on delete set null,
  changed_reason text,
  created_at timestamptz not null default now(),
  valid_during tstzrange generated always as (tstzrange(valid_from, valid_to, '[)')) stored,
  constraint chk_status_validity check (valid_to is null or valid_to > valid_from)
);

alter table listing_status_versions
  add constraint listing_status_versions_no_overlap
  exclude using gist (
    listing_id with =,
    valid_during with &&
  );
