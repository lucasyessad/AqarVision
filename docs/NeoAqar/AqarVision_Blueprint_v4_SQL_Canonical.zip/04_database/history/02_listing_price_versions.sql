create table listing_price_versions (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  price numeric(14,2) not null,
  currency text not null default 'DZD',
  valid_from timestamptz not null,
  valid_to timestamptz,
  is_current boolean not null default true,
  changed_by_user_id uuid references users(id) on delete set null,
  changed_reason text,
  created_at timestamptz not null default now(),
  valid_during tstzrange generated always as (tstzrange(valid_from, valid_to, '[)')) stored,
  constraint chk_price_validity check (valid_to is null or valid_to > valid_from)
);

alter table listing_price_versions
  add constraint listing_price_versions_no_overlap
  exclude using gist (
    listing_id with =,
    valid_during with &&
  );
