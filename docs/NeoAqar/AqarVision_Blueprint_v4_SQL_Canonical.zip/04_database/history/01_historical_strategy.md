# Historisation hybride détaillée

## 1. Etat courant
L'état actuel d'un bien reste dans `listings`.

## 2. SCD2
Tables :
- listing_price_versions
- listing_status_versions

Objectif :
- lire l'état courant rapidement
- retrouver la vérité à une date donnée

## 3. Snapshots métier
`listing_revisions`
Utilisé pour les grosses modifications de contenu.

## 4. Historique événementiel
- listing_publication_history
- listing_media_history
- listing_moderation_history

## 5. Outbox
`domain_events`

## 6. Audit
`audit_logs`
