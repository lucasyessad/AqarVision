# Incident Response

## Triggers
- suspicious access
- data leak
- abusive scraping
- webhook anomaly
- AI misuse

## Flow
contain -> assess -> rotate -> patch -> audit -> post-mortem
