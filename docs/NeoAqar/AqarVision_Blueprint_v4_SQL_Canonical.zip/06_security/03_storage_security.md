# Storage Security

- private buckets
- signed upload URLs
- short-lived access URLs
- path conventions by agency/listing
- no direct public docs bucket
