# Webhook Security

- verify signatures
- raw body
- idempotence
- event logging
- replay protection strategy
