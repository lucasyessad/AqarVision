# Threat Model

## Threats
- broken access control
- data exfiltration
- scraping
- malicious uploads
- forged billing webhooks
- LLM prompt injection

## Assets to protect
- agency data
- lead data
- user notes/favorites
- listing coordinates
- billing state
