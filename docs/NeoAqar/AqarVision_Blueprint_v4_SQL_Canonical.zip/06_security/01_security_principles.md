# Security Principles

- deny by default
- least privilege
- defense in depth
- explicit ownership checks
- logs for sensitive actions
- secure by design
