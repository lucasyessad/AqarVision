# Scope & Decisions

## Décisions déjà verrouillées
- architecture enterprise monorepo
- Supabase + PostgreSQL + PostGIS
- FR / AR / EN / ES dès le MVP
- mobile Expo équivalent web
- historisation hybride
- séparation OLTP / futur OLAP
- RLS obligatoire
- AqarPro / AqarSearch sous AqarVision

## Objectif du v4
Transformer les principes du v3 en structure SQL quasi canonique :
- colonnes
- relations
- contraintes
- indexes
- policies RLS
- helpers et triggers documentés
