# Security Flow

client
 -> auth/session
 -> app validation
 -> server mutation
 -> postgres RLS
 -> optional storage signed URL
 -> optional domain_event
 -> optional audit_log
