# History Flow

listing current state changes
 -> SCD2 price/status updated
 -> history tables updated
 -> domain_event inserted
 -> audit_log inserted
