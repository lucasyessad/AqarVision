# ERD Final — textual

users -> profiles
users -> mobile_devices -> push_tokens

agencies -> agency_branches
agencies -> agency_memberships <- users
agencies -> listings
agency_branches -> listings

listings -> listing_translations
listings -> listing_media
listings -> listing_documents
listings -> listing_price_versions
listings -> listing_status_versions
listings -> listing_revisions
listings -> listing_publication_history
listings -> listing_media_history
listings -> listing_moderation_history

users -> favorites / notes / saved_searches / view_history
listings -> leads -> conversations -> messages

agencies -> subscriptions
agencies -> ai_jobs
listings -> ai_jobs
listings/agencies/users -> domain_events
users/agencies -> audit_logs
