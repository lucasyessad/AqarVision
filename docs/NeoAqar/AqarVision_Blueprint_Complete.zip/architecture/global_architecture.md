Architecture globale

Monorepo

apps/
 web
 mobile

packages/
 ui
 database
 security
 analytics

services/
 search
 ai
 billing
