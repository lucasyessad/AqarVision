# Mobile Architecture

## Stack
- Expo React Native
- logique partagée via packages/domain
- auth Supabase PKCE
- SecureStore
- push notifications

## Principe
L’application mobile est fonctionnellement équivalente au web.

## Spécificités
- support 4 langues
- support RTL arabe
- partage des validations et DTO
- mutations sensibles via API sécurisée quand nécessaire
