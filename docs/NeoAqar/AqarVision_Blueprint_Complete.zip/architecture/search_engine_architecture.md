# Search Engine Architecture — AqarSearch

## Objectif
Concevoir un moteur de recherche immobilier performant reposant sur PostgreSQL + PostGIS au MVP.

## Pipeline
1. Normalisation des filtres
2. Validation des paramètres
3. Construction de requête SQL ciblée
4. Pagination et tri
5. Retour résultats + cartes + SEO

## Entrées principales
- transaction type
- property type
- wilaya
- commune
- neighborhood
- price min/max
- surface min/max
- rooms
- bounding box / radius

## Sources de données
- listings
- listing_translations
- listing_media
- agencies

## Index critiques
- status
- listing_type
- property_type
- published_at
- wilaya_code
- GiST sur `location`

## Règle d’or
Pas de moteur externe prématuré. PostgreSQL/PostGIS suffit au lancement.
