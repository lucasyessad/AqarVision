Structure monorepo recommandée

apps/
 web
 mobile

packages/
 ui
 domain
 database
 config
