# URL Structure

## Search
- /fr/search
- /ar/search
- /en/search
- /es/search

## Listings
- /fr/l/[slug]
- /ar/l/[slug]
- /en/l/[slug]
- /es/l/[slug]

## Agencies
- /fr/a/[slug]
- /ar/a/[slug]
- /en/a/[slug]
- /es/a/[slug]
