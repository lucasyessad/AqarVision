# Sitemap Strategy

- sitemap.xml (index)
- sitemap-fr.xml
- sitemap-ar.xml
- sitemap-en.xml
- sitemap-es.xml

Chaque sitemap liste les routes publiques indexables de sa langue.
