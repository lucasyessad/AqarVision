# Data Flow

```mermaid
flowchart TB
  AqarPro --> OLTP[(Supabase Postgres)]
  AqarSearch --> OLTP
  OLTP --> Events[domain_events]
  Events --> Warehouse[(Future Warehouse)]
```
