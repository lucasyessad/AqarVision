ERD simplifié

users
 |
agency_members
 |
agencies
 |
listings
 |
listing_media
