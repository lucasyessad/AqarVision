# Roadmap

```mermaid
gantt
  title AqarVision roadmap
  dateFormat YYYY-MM-DD
  section SaaS
  Foundations :a1, 2026-03-13, 10d
  Core CRM    :a2, after a1, 20d
  section Marketplace
  Search SEO  :b1, after a2, 15d
  Leads       :b2, after b1, 10d
  section Data Company
  Events      :c1, after b2, 10d
  Warehouse   :c2, after c1, 20d
```
