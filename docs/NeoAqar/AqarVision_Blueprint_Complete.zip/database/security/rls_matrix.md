# RLS Matrix

## Rôles logiques
- public
- authenticated_end_user
- agency_member
- super_admin

## Principes
- `listings` : lecture publique uniquement si `current_status = 'published'`
- `agency_memberships` : visible par membres de l’agence concernée et super_admin
- `favorites`, `notes`, `saved_searches` : propriétaire uniquement
- `leads` : agence propriétaire + émetteur si autorisé
- `audit_logs` : super_admin uniquement
- `ai_jobs` : agence propriétaire uniquement

## Règle d’or
Deny by default.
