# Historical Data Strategy

## Décision officielle
AqarVision adopte une historisation hybride :
- SCD2 pour prix et statut
- révisions métier pour les modifications importantes
- historique événementiel pour publication, médias, modération
- domain_events pour analytics
- audit_logs pour sécurité

## Pourquoi
- garder un OLTP performant
- préparer la future data company
- permettre des calculs temporels fiables
- éviter le mélange entre audit, métier et analytics
