create table listing_revisions (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  revision_number integer not null,
  change_type text not null,
  changed_by_user_id uuid references profiles(id),
  payload jsonb not null,
  created_at timestamptz not null default now(),
  unique (listing_id, revision_number)
);

create table listing_publication_history (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  action text not null,
  created_by_user_id uuid references profiles(id),
  created_at timestamptz not null default now()
);

create table listing_media_history (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  media_id uuid,
  action text not null,
  metadata jsonb,
  changed_by_user_id uuid references profiles(id),
  created_at timestamptz not null default now()
);
