create table listing_status_versions (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  status text not null,
  valid_from timestamptz not null,
  valid_to timestamptz,
  is_current boolean not null default true,
  changed_by_user_id uuid references profiles(id),
  changed_reason text,
  created_at timestamptz not null default now(),
  constraint chk_status_validity check (valid_to is null or valid_to > valid_from)
);

alter table listing_status_versions
  add column valid_during tstzrange
  generated always as (tstzrange(valid_from, valid_to, '[)')) stored;

create unique index idx_listing_status_current
  on listing_status_versions(listing_id)
  where is_current = true;

alter table listing_status_versions
  add constraint listing_status_versions_no_overlap
  exclude using gist (
    listing_id with =,
    valid_during with &&
  );
