Historisation hybride :

1. Etat courant dans table principale
2. Tables versions :
   listing_price_versions
   listing_status_versions

3. Domain events
4. Audit logs

Objectif :
- performance OLTP
- analytics futur
