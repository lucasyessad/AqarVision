create table plans (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  max_listings integer,
  max_ai_generations integer,
  price_monthly numeric(12,2),
  is_active boolean not null default true
);

create table subscriptions (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  plan_id uuid not null references plans(id),
  provider text not null default 'stripe',
  provider_customer_id text,
  provider_subscription_id text,
  status text not null default 'inactive',
  current_period_start timestamptz,
  current_period_end timestamptz,
  created_at timestamptz not null default now()
);
