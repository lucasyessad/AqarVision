create table ai_jobs (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  listing_id uuid references listings(id) on delete set null,
  source_locale text check (source_locale in ('fr','ar','en','es')),
  target_locale text check (target_locale in ('fr','ar','en','es')),
  job_type text not null check (job_type in ('generate','translate','classify','estimate')),
  status text not null default 'queued' check (status in ('queued','running','done','failed')),
  input_payload jsonb not null,
  output_payload jsonb,
  tokens_used integer,
  cost_estimated numeric(12,6),
  created_at timestamptz not null default now()
);
