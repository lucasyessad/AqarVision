-- Example schema

create table agencies (
 id uuid primary key,
 name text,
 created_at timestamptz default now()
);

create table listings (
 id uuid primary key,
 agency_id uuid references agencies(id),
 title text,
 price numeric,
 created_at timestamptz default now()
);
