create extension if not exists pgcrypto;
create extension if not exists postgis;
create extension if not exists btree_gist;

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  phone text,
  global_role text not null default 'end_user',
  preferred_locale text not null default 'fr' check (preferred_locale in ('fr','ar','en','es')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
