create table agencies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text,
  logo_url text,
  cover_url text,
  phone text,
  email text,
  is_verified boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table agency_branches (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  name text not null,
  wilaya_code text not null,
  commune_id bigint,
  address_text text,
  location geography(point, 4326),
  created_at timestamptz not null default now()
);

create table agency_memberships (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade,
  role text not null check (role in ('owner','admin','agent','editor','viewer')),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (agency_id, user_id)
);
