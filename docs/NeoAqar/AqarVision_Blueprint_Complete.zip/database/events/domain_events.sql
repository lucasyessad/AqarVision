CREATE TABLE domain_events (
 id uuid primary key,
 event_type text,
 payload jsonb,
 created_at timestamptz default now()
);
