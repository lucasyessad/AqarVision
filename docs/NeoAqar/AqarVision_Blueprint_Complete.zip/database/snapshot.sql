-- AqarVision snapshot.sql
-- Assemblage simplifié des objets principaux

-- core

create extension if not exists pgcrypto;
create extension if not exists postgis;
create extension if not exists btree_gist;

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  phone text,
  global_role text not null default 'end_user',
  preferred_locale text not null default 'fr' check (preferred_locale in ('fr','ar','en','es')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- organization
create table agencies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text,
  logo_url text,
  cover_url text,
  phone text,
  email text,
  is_verified boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table agency_branches (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  name text not null,
  wilaya_code text not null,
  commune_id bigint,
  address_text text,
  location geography(point, 4326),
  created_at timestamptz not null default now()
);

create table agency_memberships (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade,
  role text not null check (role in ('owner','admin','agent','editor','viewer')),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (agency_id, user_id)
);

-- listings
create table listings (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  branch_id uuid references agency_branches(id) on delete set null,
  current_price numeric(14,2) not null,
  current_status text not null default 'draft'
    check (current_status in ('draft','published','paused','sold','rented','expired','archived')),
  listing_type text not null
    check (listing_type in ('sale','rent','vacation')),
  property_type text not null,
  surface_m2 numeric(10,2),
  rooms integer,
  bathrooms integer,
  wilaya_code text not null,
  commune_id bigint,
  location geography(point, 4326),
  details jsonb not null default '{}'::jsonb,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table listing_translations (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  locale text not null check (locale in ('fr','ar','en','es')),
  title text not null,
  description text not null,
  slug text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (listing_id, locale),
  unique (locale, slug)
);

create table listing_media (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  storage_path text not null,
  is_cover boolean not null default false,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create index idx_listings_status on listings(current_status);
create index idx_listings_type on listings(listing_type, property_type);
create index idx_listings_wilaya on listings(wilaya_code);
create index idx_listings_published on listings(published_at desc);
create index idx_listings_location on listings using gist (location);

-- marketplace
create table favorites (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  listing_id uuid not null references listings(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_id, listing_id)
);

create table saved_searches (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  name text not null,
  filters jsonb not null,
  created_at timestamptz not null default now()
);

create table notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  listing_id uuid not null references listings(id) on delete cascade,
  content text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table leads (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  agency_id uuid not null references agencies(id) on delete cascade,
  sender_user_id uuid references profiles(id) on delete set null,
  status text not null default 'new'
    check (status in ('new','contacted','qualified','closed','spam')),
  message text,
  created_at timestamptz not null default now()
);

-- billing
create table plans (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  max_listings integer,
  max_ai_generations integer,
  price_monthly numeric(12,2),
  is_active boolean not null default true
);

create table subscriptions (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  plan_id uuid not null references plans(id),
  provider text not null default 'stripe',
  provider_customer_id text,
  provider_subscription_id text,
  status text not null default 'inactive',
  current_period_start timestamptz,
  current_period_end timestamptz,
  created_at timestamptz not null default now()
);

-- ai
create table ai_jobs (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  listing_id uuid references listings(id) on delete set null,
  source_locale text check (source_locale in ('fr','ar','en','es')),
  target_locale text check (target_locale in ('fr','ar','en','es')),
  job_type text not null check (job_type in ('generate','translate','classify','estimate')),
  status text not null default 'queued' check (status in ('queued','running','done','failed')),
  input_payload jsonb not null,
  output_payload jsonb,
  tokens_used integer,
  cost_estimated numeric(12,6),
  created_at timestamptz not null default now()
);

-- history prices
create table listing_price_versions (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  price numeric(14,2) not null,
  currency text not null default 'DZD',
  valid_from timestamptz not null,
  valid_to timestamptz,
  is_current boolean not null default true,
  changed_by_user_id uuid references profiles(id),
  changed_reason text,
  created_at timestamptz not null default now(),
  constraint chk_price_validity check (valid_to is null or valid_to > valid_from)
);

alter table listing_price_versions
  add column valid_during tstzrange
  generated always as (tstzrange(valid_from, valid_to, '[)')) stored;

create unique index idx_listing_price_current
  on listing_price_versions(listing_id)
  where is_current = true;

alter table listing_price_versions
  add constraint listing_price_versions_no_overlap
  exclude using gist (
    listing_id with =,
    valid_during with &&
  );

-- history status
create table listing_status_versions (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  status text not null,
  valid_from timestamptz not null,
  valid_to timestamptz,
  is_current boolean not null default true,
  changed_by_user_id uuid references profiles(id),
  changed_reason text,
  created_at timestamptz not null default now(),
  constraint chk_status_validity check (valid_to is null or valid_to > valid_from)
);

alter table listing_status_versions
  add column valid_during tstzrange
  generated always as (tstzrange(valid_from, valid_to, '[)')) stored;

create unique index idx_listing_status_current
  on listing_status_versions(listing_id)
  where is_current = true;

alter table listing_status_versions
  add constraint listing_status_versions_no_overlap
  exclude using gist (
    listing_id with =,
    valid_during with &&
  );

-- revisions & publication/media history
create table listing_revisions (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  revision_number integer not null,
  change_type text not null,
  changed_by_user_id uuid references profiles(id),
  payload jsonb not null,
  created_at timestamptz not null default now(),
  unique (listing_id, revision_number)
);

create table listing_publication_history (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  action text not null,
  created_by_user_id uuid references profiles(id),
  created_at timestamptz not null default now()
);

create table listing_media_history (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  media_id uuid,
  action text not null,
  metadata jsonb,
  changed_by_user_id uuid references profiles(id),
  created_at timestamptz not null default now()
);

-- domain events
create table domain_events (
  id uuid primary key default gen_random_uuid(),
  aggregate_type text not null,
  aggregate_id uuid not null,
  event_name text not null,
  agency_id uuid references agencies(id) on delete set null,
  actor_user_id uuid references profiles(id) on delete set null,
  payload jsonb not null,
  created_at timestamptz not null default now(),
  processed_at timestamptz
);

create index idx_domain_events_unprocessed
  on domain_events(created_at)
  where processed_at is null;

-- audit logs
create table audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_user_id uuid references profiles(id) on delete set null,
  agency_id uuid references agencies(id) on delete set null,
  entity_type text not null,
  entity_id uuid,
  action text not null,
  before_payload jsonb,
  after_payload jsonb,
  created_at timestamptz not null default now()
);
