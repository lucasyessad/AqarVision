Data Dictionary AqarVision

Principales tables :
users
agencies
agency_members
listings
listing_media
leads
favorites

Chaque table doit :
- supporter multi‑tenant
- être historisable
- être sécurisée via RLS
