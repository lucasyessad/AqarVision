# AqarVision Master Blueprint

AqarVision est l’écosystème global qui regroupe :
- AqarSearch : marketplace immobilière publique
- AqarPro : CRM immobilier pour agences et promoteurs

Vision :
Créer l’infrastructure numérique du marché immobilier algérien.

Objectifs :
1. SaaS pour agences
2. Marketplace nationale
3. Plateforme data immobilière

Stack principale :
- Next.js 14
- TypeScript
- Tailwind + Shadcn
- Supabase (PostgreSQL + Auth + Storage)
- PostGIS
- Expo (mobile)
- Architecture monorepo

Langues :
FR / AR / EN / ES

Architecture produit :
AqarVision
 ├── AqarSearch (marketplace)
 └── AqarPro (CRM agences)
