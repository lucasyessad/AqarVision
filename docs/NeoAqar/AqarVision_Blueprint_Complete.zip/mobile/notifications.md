# Notifications

## Cas d’usage
- nouveau lead
- nouveau message
- alerte sauvegardée
- baisse de prix

## Stratégie
- Expo Push au démarrage
- abstraction pour migration future si nécessaire
