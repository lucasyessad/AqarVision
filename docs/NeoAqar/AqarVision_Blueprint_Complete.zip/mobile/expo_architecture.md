# Expo Architecture

## Objectif
Application mobile équivalente au web.

## Principes
- partage de logique via packages/domain
- navigation mobile dédiée
- composants UI mobiles dédiés
- authentification sécurisée
- support 4 langues + RTL
