# Auth Mobile

- Supabase PKCE
- SecureStore pour les tokens
- deep linking
- revalidation côté serveur pour mutations sensibles
