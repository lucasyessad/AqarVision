Application mobile basée sur Expo.

Fonctions :
- recherche biens
- favoris
- contact agence
- notifications

Auth via Supabase PKCE.
