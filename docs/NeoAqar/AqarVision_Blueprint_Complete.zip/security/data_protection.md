# Data Protection

## Principes
- minimisation des données
- séparation des responsabilités
- audit des actions sensibles
- conservation maîtrisée des leads et messages
- chiffrement et secrets management via plateforme

## Points critiques
- coordonnées des biens
- documents agence
- conversations et leads
- données IA
