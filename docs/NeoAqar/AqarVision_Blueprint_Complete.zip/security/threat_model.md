Principales menaces :

- Broken access control
- Cross tenant access
- Upload malveillant
- Prompt injection IA
- Fraude Stripe

Mesures :
- RLS
- Signed uploads
- Audit logs
