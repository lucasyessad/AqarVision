# Incident Response

## Scénarios
- fuite de données
- bug RLS
- compromission webhook
- scraping massif
- clé API compromise

## Réponse
1. isoler
2. couper la fonctionnalité si nécessaire
3. analyser les logs
4. corriger
5. notifier si applicable
6. post-mortem
