# Auth Strategy

## Web
- Supabase Auth SSR
- cookies sécurisés
- session côté serveur
- contrôle d’accès renforcé côté base

## Mobile
- PKCE
- SecureStore
- rotation refresh token
- pas de secret exposé

## Rôles
- global_role dans profiles
- roles d’agence dans agency_memberships
