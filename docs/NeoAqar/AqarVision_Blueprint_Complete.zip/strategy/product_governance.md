# Product Governance

## Objectif
Maintenir une vision cohérente entre AqarVision, AqarPro et AqarSearch.

## Règles
- les décisions structurantes doivent être documentées
- chaque module doit avoir un owner métier
- toute fonctionnalité coûteuse doit être feature-flagged si activable plus tard
