# Feature Activation Plan

## Actif dès MVP
- 4 langues
- search
- SEO
- leads
- favoris
- mobile architecture
- historique hybride

## Codé mais activable progressivement
- IA avancée
- billing
- analytics avancé
- modules premium
