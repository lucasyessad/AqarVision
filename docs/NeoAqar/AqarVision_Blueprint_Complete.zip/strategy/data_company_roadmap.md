# Data Company Roadmap

## Phase 1
SaaS rentable
- AqarPro opérationnel
- données propres
- historique fiable

## Phase 2
Marketplace nationale
- AqarSearch SEO
- trafic
- analytics
- trust layer

## Phase 3
Data company
- indices prix
- warehouse
- rapports marché
- produits data B2B
