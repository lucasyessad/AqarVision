# Data Governance

## Principes
- database centralisée
- schémas versionnés
- conventions de nommage
- historique hybride
- séparation métier / audit / analytics
- préparation warehouse future
