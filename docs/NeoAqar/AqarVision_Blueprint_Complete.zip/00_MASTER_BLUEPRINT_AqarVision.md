# AqarVision — Master Blueprint

## Rôle du document
Document d’entrée principal du projet. Il synthétise la vision, l’architecture, les décisions structurantes et l’ordre de lecture du blueprint.

## Nomenclature officielle
- **AqarVision** : marque et écosystème global
- **AqarPro** : CRM / back-office / espace professionnel agences et promoteurs
- **AqarSearch** : moteur marketplace public orienté recherche immobilière

## Vision produit
AqarVision est une plateforme immobilière algérienne conçue en trois étapes :
1. **SaaS rentable** pour agences et promoteurs via AqarPro
2. **Marketplace nationale** via AqarSearch
3. **Data company immobilière** grâce à une architecture data-ready

## Positionnement
AqarVision n’est pas seulement un site immobilier. C’est :
- un outil professionnel de gestion d’annonces
- une vitrine premium pour agences
- un moteur public de recherche immobilier
- une base de données structurée sur le marché algérien

## Périmètre stratégique
### AqarPro
- onboarding agence
- multi-branches / multi-agents
- création et gestion d’annonces
- médias
- leads et messagerie
- IA de rédaction/traduction
- analytics
- facturation

### AqarSearch
- recherche publique
- filtres
- cartes
- pages détail
- favoris
- alertes
- notes privées
- pages agence SEO
- messagerie / prise de contact

## Langues officielles
- Français
- Arabe (RTL)
- Anglais
- Espagnol

## Décisions d’architecture verrouillées
- architecture **Enterprise Monorepo**
- support **web + mobile équivalent**
- base **OLTP prête OLAP** (architecture B)
- **historisation hybride** officielle
- **database centralisée**
- **RLS multi-tenant stricte**
- **feature flags** pour activer progressivement les modules coûteux

## Structure documentaire
Lire dans cet ordre :
1. `00_CLAUDE_MASTER_CONTEXT_AqarVision.md`
2. `architecture/global_architecture.md`
3. `architecture/monorepo_structure.md`
4. `database/historical_data_strategy.md`
5. `database/snapshot.sql`
6. modules M00 → M12
7. `security/threat_model.md`
8. `strategy/data_company_roadmap.md`

## Objectif du pack
Ce blueprint sert à :
- piloter le développement
- cadrer Claude Code
- aligner produit / architecture / data / sécurité
- préparer l’échelle future du projet
