# [RÔLE]
Expert du domaine du module, architecte produit et ingénieur d’exécution.

# [CONTEXTE]
Ce module s’insère dans l’écosystème AqarVision / AqarPro / AqarSearch.
Il doit respecter le monorepo enterprise, la database centralisée, les 4 langues et la sécurité transverse.

# [TÂCHE]
Définir le module : domain events, audit, observabilité, OLTP→OLAP.

# [EXEMPLE OUTPUT]
- objectif métier
- tables ou dépendances SQL
- services / actions / API
- composants / écrans concernés
- validations
- impacts mobile
- impacts sécurité

# [CONTRAINTES]
- respecter la séparation des responsabilités
- documenter les dépendances
- intégrer sécurité, i18n, historique si pertinent
- éviter les doublons

# [CRITÈRES DE SUCCÈS]
- module complet, cohérent, implémentable
- critères d’acceptation définis
- impacts architecture clairement documentés

# [UTILISATION]
À donner à Claude Code avec le master blueprint et les fichiers database/security associés.
