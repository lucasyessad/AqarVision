# M11_Analytics

ROLE
Architecte logiciel SaaS.

CONTEXTE
Module du projet AqarVision.

TACHE
Définir :
- modèle data
- logique backend
- composants frontend
- sécurité

OUTPUT
Documentation technique prête pour développement.

CONTRAINTES
Architecture monorepo.
Multi‑tenant.
Sécurité RLS.

SUCCES
Module utilisable indépendamment.

UTILISATION
Référence pour implémentation Claude Code.
