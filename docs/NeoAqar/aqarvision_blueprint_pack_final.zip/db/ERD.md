# db/ERD.md

Placeholder content for AqarVision blueprint.
