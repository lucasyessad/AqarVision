# templates/prompts_ai.md

Placeholder content for AqarVision blueprint.
