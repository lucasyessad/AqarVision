# Décisions finales verrouillées

## Produits
- AqarVision = écosystème
- AqarPro = CRM agences / promoteurs
- AqarSearch = marketplace publique

## Stack
- Next.js 14
- TypeScript
- Tailwind + shadcn
- Supabase
- PostgreSQL + PostGIS
- Expo

## i18n
- FR / AR / EN / ES
- AR en RTL

## Historisation
Système hybride :
- SCD2 pour prix et statut
- historique événementiel pour les actions
- listing_revisions pour snapshots métier
- domain_events pour analytics / warehouse
- audit_logs pour sécurité / conformité

## Architecture Data
- OLTP centralisé
- outbox event layer
- futur warehouse séparé

## Sécurité
- RLS obligatoire
- buckets privés + URLs signées
- séparation rôles globaux / rôles agence
- vérification webhooks
- protection IA
