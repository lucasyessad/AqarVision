# AqarVision Blueprint v3 — Database & Security Core

Ce pack est la suite logique du blueprint v2.
Il renforce deux couches critiques :
- la base de données transactionnelle AqarVision
- la sécurité SaaS multi-tenant

## Objectif
Fournir une base documentaire beaucoup plus proche d'un socle "production-grade" pour :
- AqarPro (CRM agences)
- AqarSearch (marketplace)
- la future couche data company

## Contenu
- schéma SQL canonique par domaine
- stratégie d'historisation hybride
- matrice RLS plus détaillée
- fonctions / triggers conceptuels
- outline snapshot SQL
- stratégie sécurité opérationnelle
- diagrammes data et sécurité

## Décisions rappelées
- architecture enterprise monorepo
- OLTP prêt pour futur OLAP
- 4 langues dès le MVP : FR / AR / EN / ES
- historisation hybride validée
- mobile équivalent web
- sécurité transversale
