# Security Flow

client -> app/web or app/mobile
 -> auth/session
 -> server validation
 -> postgres with RLS
 -> storage signed URL if media
 -> audit/domain events if action sensitive
