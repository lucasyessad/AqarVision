# ERD — focus historique

listings
 ├─ listing_price_versions
 ├─ listing_status_versions
 ├─ listing_revisions
 ├─ listing_publication_history
 ├─ listing_media_history
 └─ listing_moderation_history

listings -> domain_events
users/agencies -> audit_logs
