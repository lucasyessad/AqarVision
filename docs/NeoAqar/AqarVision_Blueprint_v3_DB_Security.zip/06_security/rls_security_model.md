# RLS Security Model

## Principe
La base de données ne doit jamais supposer que le client a raison.

## Règles
- deny by default
- public = seulement published + champs publics
- end_user = seulement ses données privées
- agency_member = seulement son agence
- super_admin = supervision explicite

## Tables prioritaires RLS
- agencies
- agency_memberships
- listings
- listing_media
- leads
- conversations
- messages
- subscriptions
- ai_jobs
