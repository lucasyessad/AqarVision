# Webhook Security

## Stripe
- vérifier la signature
- utiliser le raw body
- journaliser l'événement
- idempotence

## Principe
Aucun webhook ne doit pouvoir muter la base sans vérification explicite.
