# Incident Response

## Cas
- fuite de données
- escalade privilèges
- webhook frauduleux
- clé API compromise
- scraping massif

## Réponse
1. containment
2. rotation secrets
3. désactivation feature flag si nécessaire
4. audit
5. post-mortem
