# Storage Security

## Buckets
- listing-media : privé
- listing-documents : privé
- temp-uploads : signé uniquement

## Obligations
- signed upload URLs
- validation mime / taille
- convention de path
- pas de bucket public pour documents sensibles
