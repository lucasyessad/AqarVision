# Historical Data Strategy

## Principe
Conserver l'état courant dans la table principale.
Conserver l'historique détaillé dans des tables dédiées.

## Pourquoi
- vitesse de lecture sur le produit
- qualité analytique
- préparation data company

## Catégories
1. SCD2
2. événementiel
3. snapshots métier
4. events outbox
5. audit
