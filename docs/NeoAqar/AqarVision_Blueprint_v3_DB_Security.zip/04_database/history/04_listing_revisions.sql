create table listing_revisions (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  revision_number integer not null,
  change_type text not null,
  changed_by_user_id uuid references users(id) on delete set null,
  payload jsonb not null,
  created_at timestamptz not null default now(),
  unique(listing_id, revision_number)
);
