# Domain Events Strategy

## Objectif
Préparer la réplication future vers un warehouse sans transformer le produit en architecture event-first.

## Exemples d'événements
- listing_created
- listing_published
- price_changed
- lead_received
- subscription_started

## Règle
Tout événement métier critique peut être poussé dans domain_events au sein de la même transaction.
