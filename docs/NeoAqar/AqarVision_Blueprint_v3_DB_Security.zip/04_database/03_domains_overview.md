# Domaines de données

## 1. identities
- users
- profiles
- mobile_devices
- push_tokens

## 2. organizations
- agencies
- agency_branches
- agency_memberships
- agency_invites

## 3. listings
- listings
- listing_translations
- listing_media
- listing_documents

## 4. listing_history
- listing_price_versions
- listing_status_versions
- listing_revisions
- listing_publication_history
- listing_media_history
- listing_moderation_history

## 5. marketplace
- favorites
- notes
- saved_searches
- view_history
- leads
- conversations
- messages

## 6. monetization
- plans
- subscriptions
- billing_events
- agency_feature_entitlements

## 7. ai
- ai_prompts
- ai_jobs
- ai_usage_counters

## 8. analytics
- domain_events
- listing_views
- agency_stats_daily

## 9. audit
- audit_logs
- security_incidents (futur)
