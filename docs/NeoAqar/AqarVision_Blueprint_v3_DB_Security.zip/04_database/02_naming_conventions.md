# Naming Conventions

## Tables
- snake_case
- pluriel
- exemples :
  - agencies
  - agency_branches
  - agency_memberships
  - listings
  - listing_translations

## Colonnes
- snake_case
- FK suffixées par `_id`
- timestamps explicites : created_at, updated_at

## Index
- idx_<table>_<column(s)>
- ex : idx_listings_location_gist

## FK constraints
- fk_<table>_<reference>

## Check constraints
- chk_<table>_<meaning>

## Policies
- <table>_<action>_<audience>
- ex : listings_select_public
