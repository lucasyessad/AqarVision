create extension if not exists postgis;
create extension if not exists btree_gist;
