# Seeds

Prévoir :
- wilayas Algérie
- communes
- plans par défaut
- prompts IA par défaut
