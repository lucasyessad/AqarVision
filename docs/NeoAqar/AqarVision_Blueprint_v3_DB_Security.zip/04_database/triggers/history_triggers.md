# History Triggers

## Trigger prix
Si listings.current_price change :
- clôturer ancienne ligne current de listing_price_versions
- insérer nouvelle ligne
- insérer domain_event price_changed

## Trigger statut
Si listings.current_status change :
- clôturer ancienne ligne current de listing_status_versions
- insérer nouvelle ligne
- insérer domain_event status_changed
