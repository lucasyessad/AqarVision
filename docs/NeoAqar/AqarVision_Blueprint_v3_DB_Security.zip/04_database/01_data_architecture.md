# [RÔLE]
Architecte data senior, spécialiste PostgreSQL / PostGIS / SaaS multi-tenant.

# [CONTEXTE]
AqarVision doit servir simultanément :
- le produit transactionnel quotidien
- la marketplace publique
- la future data company

Le modèle doit être :
- relationnel en priorité
- flexible là où nécessaire
- historisable
- sécurisé par RLS

# [TÂCHE]
Définir l'architecture data cible :
- séparation domaines
- stratégie OLTP
- préparation OLAP
- conventions de modélisation

# [EXEMPLE OUTPUT]
Domaines :
- identities
- organizations
- listings
- marketplace
- billing
- ai
- analytics
- audit

# [CONTRAINTES]
- pas de SQL métier dispersé hors dossier database
- JSONB seulement pour les champs réellement variables
- toutes les tables sensibles doivent être RLS-ready
- penser warehouse futur sans sur-ingénierie

# [CRITÈRES DE SUCCÈS]
- le schéma est lisible
- les domaines sont cohérents
- la maintenance est simple
- le futur warehouse est préparé

# [UTILISATION]
Ce document est la porte d'entrée de la couche base de données.
