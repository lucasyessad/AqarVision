# M02 Agencies Branches Team

## Objectifs
- agences, branches, memberships, multi-agents; tables agencies, agency_branches, agency_memberships

## Tests / Validation
- isolation inter-agence; rôles; accès branche
