# M04 Media Storage

## Objectifs
- upload, cover, ordre, sécurité; tables listing_media, listing_media_history

## Tests / Validation
- upload autorisé/refusé; cover unique
