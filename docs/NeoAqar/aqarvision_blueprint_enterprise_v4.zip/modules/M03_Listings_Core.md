# M03 Listings Core

## Objectifs
- CRUD annonces, workflow draft/published, 4 langues, historisation hybride; tables listings, listing_translations, listing_documents, listing_price_versions, listing_status_versions, listing_revisions, listing_publication_history

## Tests / Validation
- publication impossible sans contenu requis; historique cohérent; slugs uniques; tests changement prix/statut
