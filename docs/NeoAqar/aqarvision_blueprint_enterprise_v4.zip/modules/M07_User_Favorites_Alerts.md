# M07 User Favorites Alerts

## Objectifs
- favoris, notes, recherches sauvegardées, alertes futures; tables favorites, notes, saved_searches

## Tests / Validation
- CRUD perso; isolation user
