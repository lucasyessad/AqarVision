# M00 Foundations

## Objectifs
- monorepo, i18n 4 langues, design system, observabilité, feature flags, conventions repo

## Tests / Validation
- structure repo validée; locales configurées; lint/format/test base prêts
