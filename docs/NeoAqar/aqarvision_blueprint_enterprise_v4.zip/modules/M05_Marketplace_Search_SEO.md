# M05 Marketplace Search SEO

## Objectifs
- moteur de recherche, carte, pages publiques, SEO multilingue; tables listings, listing_translations, favorites, saved_searches, listing_views

## Tests / Validation
- filtres; géospatial; hreflang; sitemap
