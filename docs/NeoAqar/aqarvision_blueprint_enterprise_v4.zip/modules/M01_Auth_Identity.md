# M01 Auth Identity

## Objectifs
- inscription/connexion, profils, rôles, auth web/mobile; tables users, mobile_devices, push_tokens

## Tests / Validation
- login/logout; accès profil; séparation rôles
