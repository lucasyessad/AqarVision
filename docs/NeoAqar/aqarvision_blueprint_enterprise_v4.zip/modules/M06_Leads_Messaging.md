# M06 Leads Messaging

## Objectifs
- leads, conversations, messages; tables leads, conversations, messages

## Tests / Validation
- conversation lead; permissions participants
