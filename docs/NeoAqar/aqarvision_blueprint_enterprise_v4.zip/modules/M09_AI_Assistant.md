# M09 AI Assistant

## Objectifs
- génération, traduction, enrichissement, coût mesuré; tables ai_prompts, ai_jobs

## Tests / Validation
- exécution; validation output; quota
