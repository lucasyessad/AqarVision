# M11 Analytics Events

## Objectifs
- vues, domain_events, préparation warehouse; tables listing_views, domain_events, audit_logs

## Tests / Validation
- émission events; cohérence payloads
