# M08 Billing Stripe

## Objectifs
- plans, abonnements, quotas, feature entitlements; tables plans, subscriptions, feature_flags, agency_feature_entitlements

## Tests / Validation
- activation plan; quotas; changement abonnement
