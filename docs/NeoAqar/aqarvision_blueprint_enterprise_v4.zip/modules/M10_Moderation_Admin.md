# M10 Moderation Admin

## Objectifs
- reports, moderation actions, supervision; tables reports, moderation_actions, audit_logs

## Tests / Validation
- signalement; action admin; traçabilité
