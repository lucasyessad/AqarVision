# M12 Deployment Operations

## Objectifs
- CI/CD, monitoring, backups, sécurité préprod, FinOps

## Tests / Validation
- pipeline; restauration; checklist pré-lancement
