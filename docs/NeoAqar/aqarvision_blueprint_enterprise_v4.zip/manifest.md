# Manifest V4

## architecture
- 01_global_architecture.md
- 02_monorepo_structure.md
- 03_i18n_architecture.md
- 04_oltp_olap_strategy.md
- 05_marketplace_search_engine.md
- 06_mobile_full_parity.md
- 07_design_system_strategy.md

## database
- snapshot.sql
- ERD.md
- data_dictionary.md
- schema/*.sql
- history/*.sql
- rls/*.md
- functions/*.md
- triggers/triggers.md
- seeds/reference_data.md

## security
- 01_threat_model.md
- 02_security_controls.md
- 03_storage_security.md
- 04_ai_security.md
- 05_webhook_security.md
- 06_incident_response.md
- 07_preprod_checklist.md

## strategy
- 01_product_roadmap.md
- 02_monetization.md
- 03_data_company_roadmap.md
- 04_finops.md
- 05_feature_activation_plan.md

## governance
- 01_data_governance.md
- 02_data_retention.md
- 03_compliance_algeria.md
- 04_business_continuity.md

## seo
- 01_multilingual_seo.md
- 02_programmatic_seo.md

## mobile
- 01_mobile_strategy.md
- 02_push_offline_auth.md

## ai
- 01_ai_architecture.md
- 02_prompt_lifecycle.md

## analytics
- 01_event_taxonomy.md
- 02_future_warehouse.md

## modules
- M00_Foundations.md
- M01_Auth_Identity.md
- M02_Agencies_Branches_Team.md
- M03_Listings_Core.md
- M04_Media_Storage.md
- M05_Marketplace_Search_SEO.md
- M06_Leads_Messaging.md
- M07_User_Favorites_Alerts.md
- M08_Billing_Stripe.md
- M09_AI_Assistant.md
- M10_Moderation_Admin.md
- M11_Analytics_Events.md
- M12_Deployment_Operations.md

## diagrams
- erd.mmd
- search_flow.mmd
- history_flow.mmd
- roadmap_gantt.mmd

## prompts
- claude_code_master_prompt.md
- module_execution_template.md

## checklists
- module_definition_of_done.md
- prelaunch_checklist.md
