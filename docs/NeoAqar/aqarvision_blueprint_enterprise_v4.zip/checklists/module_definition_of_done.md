# Module Definition of Done

Un module est terminé si : tables documentées, flows/API documentés, sécurité/RLS documentées, tests identifiés, critères d'acceptation listés.
