# Business Continuity

- backups
- RTO/RPO
- restauration
- procédures incident
