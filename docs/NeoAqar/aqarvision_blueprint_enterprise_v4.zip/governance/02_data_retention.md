# Data Retention

- durée de conservation leads
- logs
- documents
- comptes supprimés
