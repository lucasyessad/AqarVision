# Data Governance

- ownership
- data dictionary
- source de vérité SQL
- gouvernance événements
