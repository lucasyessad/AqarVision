-- Snapshot V4
-- Déploiement réel via migrations versionnées.
-- Ce snapshot sert de vue canonique du schéma cible.

\i schema/00_extensions.sql
\i schema/01_enums.sql
\i schema/02_identity.sql
\i schema/03_organizations.sql
\i schema/04_listings.sql
\i history/02_scd2_prices.sql
\i history/03_scd2_statuses.sql
\i history/04_listing_revisions.sql
\i history/05_publication_media_moderation_history.sql
\i schema/05_marketplace.sql
\i schema/06_billing.sql
\i schema/07_ai.sql
\i schema/08_analytics.sql
\i schema/09_admin_moderation.sql
