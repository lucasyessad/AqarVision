# Historical Data Strategy

Modèle hybride :

SCD2 :
- listing_price_versions
- listing_status_versions
- agency_subscription_versions (future)

Event history :
- listing_publication_history
- listing_media_history
- listing_moderation_history

Business revisions :
- listing_revisions

Data bridge :
- domain_events

Compliance/security :
- audit_logs
