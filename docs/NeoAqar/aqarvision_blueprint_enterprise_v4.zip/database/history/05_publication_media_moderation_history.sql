create table listing_publication_history (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  action text not null,
  created_by_user_id uuid references users(id),
  created_at timestamptz not null default now()
);

create table listing_media_history (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  media_id uuid,
  action text not null,
  metadata jsonb,
  changed_by_user_id uuid references users(id),
  created_at timestamptz not null default now()
);

create table listing_moderation_history (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  action text not null,
  reason text,
  moderator_user_id uuid references users(id),
  payload jsonb,
  created_at timestamptz not null default now()
);
