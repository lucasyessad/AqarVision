# Reference Data

À prévoir :
- wilayas
- communes
- plans initiaux
- flags initiaux
- prompts initiaux
