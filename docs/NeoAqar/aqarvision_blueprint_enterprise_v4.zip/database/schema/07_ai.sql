create table ai_prompts (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  version integer not null,
  prompt_text text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(name, version)
);

create table ai_jobs (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  listing_id uuid references listings(id) on delete cascade,
  prompt_id uuid references ai_prompts(id),
  source_locale text,
  target_locale text,
  status ai_job_status not null default 'queued',
  input_payload jsonb not null,
  output_payload jsonb,
  tokens_used integer,
  estimated_cost numeric(12,6),
  created_at timestamptz not null default now()
);
