create type user_role as enum ('end_user', 'super_admin');
create type agency_role as enum ('owner', 'admin', 'agent', 'editor', 'viewer');
create type listing_type as enum ('sale', 'rent', 'vacation');
create type property_type as enum ('apartment', 'villa', 'terrain', 'local_commercial', 'office', 'building', 'farm', 'hangar', 'other');
create type listing_status as enum ('draft', 'published', 'paused', 'sold', 'rented', 'expired', 'archived');
create type document_type as enum ('acte', 'livret_foncier', 'promesse', 'cc', 'autre');
create type lead_status as enum ('new', 'contacted', 'qualified', 'closed', 'spam');
create type subscription_status as enum ('trialing', 'active', 'past_due', 'canceled', 'incomplete');
create type ai_job_status as enum ('queued', 'running', 'completed', 'failed');
