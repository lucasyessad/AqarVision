# Triggers

Triggers recommandés :
- updated_at auto
- fermeture version courante prix
- fermeture version courante statut
- émission domain_event sur changements critiques
- journalisation audit pour actions sensibles
