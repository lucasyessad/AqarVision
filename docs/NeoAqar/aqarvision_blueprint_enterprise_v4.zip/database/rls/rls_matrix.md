# RLS Matrix

Roles :
- public
- authenticated_end_user
- agency_member
- super_admin

Par table :
- listings : public select si published ; agency_member CRUD si membre
- listing_translations : mêmes règles que listing parent
- favorites / notes / saved_searches : user only
- leads : sender + agence propriétaire
- conversations/messages : participants only
- subscriptions : agency owner/admin
- ai_jobs : agency only
- reports/moderation : admin scope
