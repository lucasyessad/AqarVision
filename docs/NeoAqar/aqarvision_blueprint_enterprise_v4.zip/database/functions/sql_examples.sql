-- Exemples de logique transactionnelle

-- Exemple changement prix
-- 1. close current scd2 row
-- 2. insert new scd2 row
-- 3. update listings.current_price
-- 4. emit domain_event
