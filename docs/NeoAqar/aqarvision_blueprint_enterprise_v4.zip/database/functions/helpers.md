# Database Helper Functions

Fonctions prévues :
- is_agency_member(user_id uuid, agency_id uuid)
- is_agency_admin(user_id uuid, agency_id uuid)
- set_updated_at()
- emit_domain_event(...)
- close_current_price_version(...)
- close_current_status_version(...)
