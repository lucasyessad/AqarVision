# ERD

Voir `diagrams/erd.mmd`.

Cette version ERD couvre :
- identité
- organisation
- annonces
- historique
- marketplace
- billing
- IA
- analytics
- admin
