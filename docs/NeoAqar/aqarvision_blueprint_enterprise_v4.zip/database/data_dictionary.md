# Data Dictionary

## users
Utilisateurs finaux, agents et admins système.

## agencies
Entités professionnelles propriétaires des annonces.

## agency_branches
Implantations multi-villes des agences.

## agency_memberships
Rattachement utilisateur -> agence + rôle.

## listings
Table courante des biens ; source OLTP de référence pour l'état actif.

## listing_translations
Titre/description/slug par locale (fr/ar/en/es).

## listing_media
Photos et médias d'annonce.

## listing_documents
Pièces documentaires métier.

## listing_price_versions
Historique SCD2 du prix.

## listing_status_versions
Historique SCD2 du statut.

## listing_revisions
Snapshots ciblés des modifications métier importantes.

## favorites
Sauvegarde utilisateur.

## saved_searches
Recherches sauvegardées.

## notes
Notes privées utilisateur sur un bien.

## leads
Contacts entrants sur annonces.

## conversations
Thread logique lié à un lead.

## messages
Messages dans une conversation.

## plans
Plans de pricing.

## subscriptions
Abonnements agence.

## feature_flags
Catalogue des fonctionnalités activables.

## agency_feature_entitlements
Activation/droits par agence.

## ai_prompts
Prompts versionnés.

## ai_jobs
Exécutions IA.

## listing_views
Événements de consultation.

## domain_events
Outbox analytique.

## audit_logs
Conformité et sécurité.

## reports
Signalements utilisateurs.

## moderation_actions
Actions de modération.
