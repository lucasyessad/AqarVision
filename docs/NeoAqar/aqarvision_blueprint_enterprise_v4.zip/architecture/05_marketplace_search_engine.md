# Marketplace Search Engine

Inputs :
- listing_type
- property_type
- wilaya
- commune
- quartier
- prix
- surface
- pièces
- filtres details

Engine :
- Postgres + PostGIS
- filtres SQL
- index composites
- index GiST géospatial
- JSONB ciblé uniquement pour les variations métier locales
