# Monorepo Structure

aqarvision/
  apps/
    web/
    mobile/
  packages/
    domain/
    database/
    security/
    feature-flags/
    analytics/
    ui-web/
    ui-mobile/
    api-client/
    config/
  docs/

Description :
- apps/web : Next.js 14 App Router
- apps/mobile : Expo React Native
- packages/domain : logique métier pure, DTO, validators
- packages/database : SQL, migrations, RLS, triggers, types
- packages/security : patterns sécurité
- packages/feature-flags : activation progressive
- packages/analytics : taxonomie événements et pont vers futur warehouse
