# OLTP / OLAP Strategy

Architecture B :
- OLTP : base transactionnelle métier
- OLAP : entrepôt analytique futur

OLTP optimisé pour :
- CRUD
- recherche
- dashboard agence
- messagerie
- publication

Outbox :
- domain_events sert de couche de transition
