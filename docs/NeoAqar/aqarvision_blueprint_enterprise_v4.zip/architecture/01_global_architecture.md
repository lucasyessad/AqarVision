# Global Architecture

AqarVision est un système organisé en quatre couches.

1. Produit Pro
- agences, branches, memberships
- création, édition et publication d'annonces
- médias
- leads, conversations, messages
- analytics agence
- IA rédaction/traduction/enrichissement

2. Produit Public
- moteur de recherche
- pages annonces
- pages agences
- carte
- favoris, notes, alertes
- messagerie
- SEO programmatique

3. Couche Data
- PostgreSQL transactionnel
- PostGIS
- historisation hybride
- outbox `domain_events`
- préparation warehouse

4. Sécurité & Gouvernance
- RLS multi-tenant
- audit trail
- secrets management
- rétention
- DRP / BCP
