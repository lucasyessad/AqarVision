# i18n Architecture

Locales :
- fr
- ar
- en
- es

Règles :
- dir="rtl" uniquement pour ar
- fallback : locale demandée -> fr -> en
- publication d'une annonce : 4 traductions disponibles ou auto-générées puis validées
- slugs uniques par locale
