# Design System Strategy

Inspirations :
- Stripe
- Linear
- Airbnb
- Zillow

Principes :
- premium, sobre, mobile-first
- support RTL natif
- composants web et mobile cohérents
- design tokens centralisés
