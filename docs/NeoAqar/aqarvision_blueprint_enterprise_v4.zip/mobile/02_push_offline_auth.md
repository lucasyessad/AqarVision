# Push, Offline & Auth

- Expo Push
- cache local partiel
- SecureStore
- reconnexion transparente
