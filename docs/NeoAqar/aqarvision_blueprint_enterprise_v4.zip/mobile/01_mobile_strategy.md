# Mobile Strategy

- Expo
- parité complète avec le web
- partage logique métier
- auth PKCE
