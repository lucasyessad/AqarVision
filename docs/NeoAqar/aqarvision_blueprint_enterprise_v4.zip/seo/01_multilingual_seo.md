# Multilingual SEO

- hreflang fr/ar/en/es
- x-default
- canonical par locale
- sitemap par langue
- structured data
