# Storage Security

- buckets privés
- documents sensibles jamais publics
- contrôle MIME / taille
- URLs signées courtes
