# AI Security

- prompts versionnés
- pas de contexte cross-tenant
- validation structurée
- journalisation coût et usage
