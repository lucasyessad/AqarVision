# Threat Model

Menaces : broken access control, scraping massif, uploads malicieux, webhook forgé, prompt injection, fuite de données.
