# Preprod Security Checklist

- RLS active partout
- aucun bucket public sensible
- CSP active
- monitoring actif
- secrets hors code
