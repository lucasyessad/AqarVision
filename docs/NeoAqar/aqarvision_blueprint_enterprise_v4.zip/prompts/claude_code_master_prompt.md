# Claude Code Master Prompt

Respecter strictement le monorepo enterprise, la centralisation SQL, les 4 langues, le support RTL, l'historisation hybride, la séparation domain/ui/infrastructure et les specs modules M00 à M12.
