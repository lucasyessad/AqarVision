# Module Execution Template

1. lire la spec du module
2. identifier tables
3. validations
4. sécurité/RLS
5. UI
6. logique métier
7. tests
8. documentation
