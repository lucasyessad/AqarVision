# Prompt Lifecycle

- rédaction
- versioning
- activation
- suivi coût
- revue qualité
