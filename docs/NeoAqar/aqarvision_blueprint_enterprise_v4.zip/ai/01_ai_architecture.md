# AI Architecture

- génération d'annonces
- traduction fr/ar/en/es
- enrichissement
- classification
