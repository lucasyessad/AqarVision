# FinOps

Coûts à surveiller : DB, storage, bande passante, IA, push, maps
