# Future Warehouse

- réplication domain_events
- agrégats temporels
- dashboards
- produits data
