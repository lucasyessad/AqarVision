# Event Taxonomy

- listing_created
- listing_published
- price_changed
- listing_viewed
- favorite_added
- lead_received
- message_sent
