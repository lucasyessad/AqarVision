
# AqarVision — Architecture Complète Type Zillow Adaptée à l’Algérie

## Objectif du document
Ce document décrit une architecture cible inspirée des grandes plateformes immobilières comme Zillow, Idealista, SeLoger ou PropertyFinder, adaptée au contexte d’AqarVision.

L’objectif n’est pas de copier leur stack exacte, mais de reproduire les **grands principes structurants** qui font leur force :

- moteur de recherche très performant
- acquisition et gestion massive d’annonces
- CRM professionnel pour agences
- couche data puissante
- capacité à produire des estimations, des tendances et des produits analytiques

---

# 1. Le vrai modèle “type Zillow”

Une grande plateforme immobilière n’est pas seulement un site de recherche.

Elle repose sur **4 couches stratégiques** :

1. **Marketplace publique**
2. **Plateforme professionnelle / CRM**
3. **Infrastructure d’ingestion et de qualité des annonces**
4. **Infrastructure data et modèles de valorisation**

Dans AqarVision, cela devient :

- **AqarSearch** = la couche marketplace publique
- **AqarPro** = la couche CRM / publication / gestion agences
- **AqarVision Data Layer** = la couche data, historique, analytics, scoring, estimation
- **AqarVision Ingestion Layer** = la couche d’import, nettoyage, normalisation et diffusion

---

# 2. Architecture macro recommandée

```text
AqarVision
├── AqarSearch (marketplace publique)
├── AqarPro (CRM agences / promoteurs)
├── Ingestion Layer (imports / nettoyage / synchronisation)
├── Data Layer (historique / analytics / scoring)
└── Services transverses (auth, billing, notifications, AI, moderation)
```

## Version de départ recommandée
Au démarrage, on garde un **modular monolith** propre, avec une base transactionnelle centrale.  
On n’attaque pas directement en microservices complets.

Pourquoi :
- coût plus faible
- complexité plus faible
- time-to-market plus rapide
- plus simple à maintenir

## Évolution possible
Quand la traction augmente :
- séparation du moteur de recherche
- séparation des analytics
- séparation des workers IA et ingestion
- séparation du data warehouse

---

# 3. Couche 1 — AqarSearch (Marketplace Publique)

## Mission
Transformer les annonces des agences en expérience publique ultra lisible.

## Fonctionnalités cœur
- recherche avancée
- carte interactive
- pages listing
- pages agence
- favoris
- alertes
- pages SEO locales
- comparaison de biens
- historique de prix
- biens similaires

## Architecture recommandée
### Frontend
- Next.js App Router
- SSR / ISR
- routes localisées
- rendu optimisé SEO

### Backend
- lecture depuis PostgreSQL / PostGIS
- search service interne
- éventuellement moteur externe plus tard

### Données lues
- `listings`
- `listing_translations`
- `listing_media`
- `agencies`
- `listing_price_versions`
- `favorites`
- `saved_searches`

## KPI marketplace
- volume d’annonces publiées
- nombre de recherches
- nombre de clics fiche
- taux de contact
- nombre de favoris
- temps passé par fiche
- nombre d’alertes créées

---

# 4. Couche 2 — AqarPro (CRM Agences)

## Mission
Offrir un outil réellement utile aux agences.

## Ce que doit gérer AqarPro
- création et modification d’annonces
- gestion équipe
- branches
- leads
- messagerie
- workflow publication
- traduction
- IA rédactionnelle
- analytics agence
- branding vitrine

## Fonctionnalités premium à terme
- diffusion multicanale
- scoring qualité annonce
- dashboard conversion
- multi-utilisateurs avancé
- import massif

## Architecture recommandée
### Frontend
- dashboard web dense mais lisible
- version mobile équivalente pour consultation / actions rapides

### Backend
- services listings
- services leads
- services agencies
- services AI
- services billing

### Données
- `agencies`
- `agency_branches`
- `agency_memberships`
- `listings`
- `listing_revisions`
- `leads`
- `conversations`
- `messages`
- `subscriptions`
- `ai_jobs`

## KPI CRM
- nombre d’annonces actives
- taux de complétude
- taux de publication
- leads reçus
- délai de réponse
- taux de conversion
- usage IA
- usage équipe

---

# 5. Couche 3 — Ingestion Layer

C’est l’une des couches les plus importantes si tu veux scaler.

## Mission
Permettre d’alimenter la plateforme rapidement, sans dépendre uniquement de saisie manuelle.

## Sources d’ingestion possibles
- formulaire manuel agence
- import Excel / CSV
- import depuis ancien CRM
- import depuis fichiers structurés
- synchronisation d’annonces externes
- récupération d’annonces historiques propres

## Pipeline recommandé
```text
Source brute
→ Parsing
→ Validation
→ Normalisation
→ Déduplication
→ Enrichissement
→ Insertion dans OLTP
→ Event domain / analytics
```

## Services nécessaires
- import service
- mapping service
- deduplication service
- media normalization service
- validation service

## Règles de qualité
- adresse normalisée
- wilaya / commune obligatoires
- transaction type standardisé
- property type standardisé
- document type standardisé
- photos dédupliquées si possible
- slugs recalculés proprement

## Pourquoi cette couche est stratégique
Parce que la vraie bataille d’une marketplace immobilière, ce n’est pas seulement l’UX.  
C’est **la profondeur et la qualité de l’inventaire**.

---

# 6. Couche 4 — Data Layer

C’est la couche qui transforme AqarVision en entreprise de données.

## Mission
Capitaliser sur :
- l’historique
- les comportements utilisateurs
- les tendances marché
- les performances agences
- les variations de prix

## Sous-couches
### 1. OLTP
Base transactionnelle produit.

### 2. Outbox / domain events
`domain_events`

### 3. Warehouse futur
- BigQuery
- ClickHouse
- Snowflake
- autre solution adaptée plus tard

### 4. Data marts
- market trends
- agency performance
- lead conversion
- pricing index

## Données critiques à accumuler
- historique des prix
- historique de statut
- changements de contenu
- vues listings
- recherches populaires
- actions utilisateurs
- leads
- performance des agences

## Produits data possibles
- indice prix par wilaya
- indice prix par commune
- temps de vente moyen
- tension locative
- zones chaudes
- score de liquidité
- score qualité annonce
- score fiabilité agence

---

# 7. Architecture technique recommandée

## Étape 1 — Architecture simple mais robuste
### Web
- Next.js 14
- App Router
- SSR / ISR
- i18n 4 langues

### Mobile
- Expo / React Native
- PKCE
- notifications
- cache léger

### Backend
- Supabase
- PostgreSQL
- PostGIS
- Edge Functions / handlers ciblés

### Storage
- Supabase Storage
- buckets privés
- signed URLs

### Auth
- Supabase Auth
- profils
- rôles globaux
- rôles agence

### Billing
- Stripe

### AI
- provider LLM abstrait
- prompts versionnés
- usage journalisé

### Search
- Postgres + PostGIS + index intelligents

---

# 8. Quand basculer vers une architecture plus éclatée

Tu ne dois pas aller trop tôt vers les microservices.  
Mais tu dois savoir **quand séparer**.

## Séparer la recherche quand :
- volume annonces élevé
- filtres trop lourds
- latence sur recherche
- besoin de ranking avancé
- besoin de search suggestions

## Séparer analytics / warehouse quand :
- tu veux des dashboards massifs
- les domain events deviennent volumineux
- l’OLTP commence à être pollué par les requêtes analytiques

## Séparer ingestion quand :
- imports massifs fréquents
- enrichissement complexe
- déduplication coûteuse

## Séparer IA quand :
- usages multiples
- coûts élevés
- prompts nombreux
- besoins d’observabilité spécifiques

---

# 9. Moteur de recherche immobilier avancé

## MVP recommandé
- PostgreSQL
- PostGIS
- filtres SQL
- index GiST
- search service applicatif

## Phase avancée
Ajouter éventuellement :
- Elastic / OpenSearch
- moteur de ranking
- recherche textuelle enrichie
- suggestions automatiques
- synonymes métiers
- scoring de pertinence

## Inputs recherche à prévoir
- transaction
- type de bien
- budget
- surface
- pièces
- wilaya
- commune
- quartier
- géorecherche
- options détaillées

## Outputs enrichis
- cards listing
- points carte
- facets / filtres disponibles
- résultats sponsorisés
- biens similaires
- historique de prix

---

# 10. Algorithme d’estimation des biens

Il ne faut pas le lancer trop tôt commercialement, mais il faut le préparer.

## Ce qu’il consomme
- historique de prix
- propriétés comparables
- localisation
- surface
- nombre de pièces
- type bien
- temps sur marché
- variation du marché local

## Étapes d’évolution
### Phase 1
Heuristiques simples :
- comparables locaux
- médiane / moyenne pondérée

### Phase 2
Modèle statistique supervisé

### Phase 3
Produit premium :
- fourchette de confiance
- score de fiabilité estimation
- explication des facteurs

## Pourquoi c’est stratégique
Parce que l’estimation est un des produits qui crée le plus de valeur, de trafic et de rétention.

---

# 11. Acquisition d’annonces à grande échelle

C’est le vrai nerf de la guerre.

## Les canaux d’acquisition à prévoir
- démarchage agences
- import catalogue existant
- onboarding avec assistance
- import semi-automatique
- partenariat promoteurs
- import historique structuré

## Fonctionnalités critiques pour atteindre la masse
- import CSV/Excel
- templates d’import
- détection doublons
- mode brouillon / validation
- publication en lot
- édition rapide de masse

## Ce qui fera basculer la plateforme
Pas seulement la recherche.
Mais :
- la facilité d’onboarding des agences
- la facilité de publication
- la qualité de la présentation
- la génération de leads

---

# 12. L’erreur que font 90 % des marketplaces immobilières

Elles construisent :
- un joli site
- quelques filtres
- une page détail correcte

Mais elles oublient :
- l’outil agence
- l’import massif
- la qualité des données
- l’historisation
- la distribution
- le CRM leads

Résultat :
- peu d’annonces
- faible rétention agences
- peu de data
- pas d’avantage structurel

---

# 13. Ce que doit vraiment devenir AqarVision

Pas seulement :
- un portail d’annonces

Mais :
- une plateforme de publication
- un outil d’exploitation agence
- un moteur de recherche national
- une base de connaissance immobilière
- une future couche data B2B

## Vision cible
```text
AqarVision
├── AqarPro : outil de travail des agences
├── AqarSearch : couche publique et acquisition
├── Ingestion Layer : accélérateur d’inventaire
└── Data Layer : valeur long terme
```

---

# 14. Recommandation stratégique finale

## Ce qu’il faut faire tout de suite
- finir AqarPro minimal
- finir AqarSearch utilisable
- rendre la publication très simple
- rendre la recherche très claire
- accumuler l’historique proprement

## Ce qu’il faut préparer sans l’activer trop tôt
- AI avancée
- scoring quartier
- estimation
- warehouse
- APIs data

## Ce qu’il ne faut surtout pas faire
- sur-architecturer trop tôt
- négliger l’inventaire
- négliger les agences
- négliger la couche data
- négliger la qualité des annonces

---

# Conclusion

Le vrai modèle “type Zillow” n’est pas un simple site immobilier.  
C’est un **écosystème à 4 couches** :

1. marketplace publique
2. CRM professionnel
3. moteur d’ingestion / normalisation
4. infrastructure data

AqarVision est bien positionné pour suivre ce chemin, à condition de rester discipliné :

- inventaire d’abord
- valeur agence ensuite
- recherche et conversion ensuite
- data et estimation ensuite

C’est cette logique qui peut faire d’AqarVision non seulement une proptech, mais une **infrastructure immobilière nationale**.
