# Design System

## Inspirations
- Stripe
- Linear
- Airbnb
- marketplaces premium

## Principes
- mobile-first
- composants cohérents
- accessibilité
- FR / AR / EN / ES
- RTL robuste
