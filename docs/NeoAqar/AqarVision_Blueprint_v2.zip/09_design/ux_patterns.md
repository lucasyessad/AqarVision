# UX Patterns

## AqarSearch
- recherche rapide
- carte + résultats
- fiches lisibles
- CTA clairs

## AqarPro
- dashboard dense mais simple
- flux de création annonce guidé
- actions rapides
