# Mobile Architecture

## Positionnement
Application mobile équivalente au web.

## Stack
- Expo
- React Native
- i18n
- SecureStore
- push notifications

## Partage
- logique métier via packages/domain
- types et validations partagés
- UI distincte web/mobile

## Auth
- PKCE
- deep linking
- secure token storage
