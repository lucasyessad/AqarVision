# Monorepo Structure

## apps
### web
- Next.js App Router
- SSR / ISR
- AqarPro + AqarSearch

### mobile
- Expo React Native
- i18n 4 langues
- équivalent web

## packages
### domain
Règles métier pures

### database
SQL, RLS, migrations, dictionnaire

### security
Threat model, guards, standards

### feature-flags
Activation progressive modules coûteux
