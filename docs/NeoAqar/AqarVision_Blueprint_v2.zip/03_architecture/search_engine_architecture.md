# Search Engine Architecture

## Objectif
Construire un moteur de recherche immobilier performant sans moteur externe au MVP.

## Sources
- listings
- listing_translations
- listing_media
- agences

## Filtres
- type transaction
- type bien
- prix
- surface
- pièces
- wilaya
- commune
- quartier
- options details

## Géospatial
- PostGIS
- ST_DWithin
- GiST index
- bounding box

## Sortie
- cards
- map points
- SEO pages
