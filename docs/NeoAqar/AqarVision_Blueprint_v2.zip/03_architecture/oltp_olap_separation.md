# OLTP / OLAP Separation

## OLTP
- Supabase Postgres
- opérations transactionnelles
- lecture / écriture produit

## OLAP futur
- warehouse séparé
- agrégations
- dashboards marché
- data products

## Pont
- domain_events
- réplication future / ETL
