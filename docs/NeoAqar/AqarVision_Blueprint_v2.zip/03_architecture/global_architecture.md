# Architecture globale

## Style
- monorepo enterprise
- modular SaaS
- domain-driven structure
- database centralisée
- sécurité transversale

## Structure cible
- apps/web
- apps/mobile
- packages/domain
- packages/database
- packages/ui-web
- packages/ui-mobile
- packages/security
- packages/analytics
- packages/feature-flags
- packages/config

## Produits
- AqarPro : zone privée / CRM
- AqarSearch : zone publique / marketplace
