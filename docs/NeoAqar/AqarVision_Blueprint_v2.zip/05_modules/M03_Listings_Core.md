# M03_Listings_Core

## [RÔLE]
Expert principal du domaine : biens, traductions, historisation.

## [CONTEXTE]
Ce module s'inscrit dans l'écosystème AqarVision :
- AqarPro côté agences
- AqarSearch côté public
- architecture 4 langues
- mobile équivalent web
- sécurité multi-tenant
- historisation hybride si concernée

## [TÂCHE]
Définir précisément :
- périmètre fonctionnel
- modèle de données
- flux utilisateur
- interfaces attendues
- sécurité
- dépendances
- critères d'acceptation

## [EXEMPLE OUTPUT]
- tables / relations
- server actions ou API contracts
- composants ou écrans attendus
- policies RLS si concerné
- checklists tests

## [CONTRAINTES]
- respecter le monorepo
- ne pas sortir le SQL de `04_database`
- ne pas dupliquer les types
- toujours penser 4 langues
- toujours penser mobile et sécurité

## [CRITÈRES DE SUCCÈS]
Le module est réussi si :
- son périmètre est clair
- la donnée est proprement modélisée
- l'implémentation future ne nécessite pas d'interprétation majeure
- les dépendances sont explicites

## [UTILISATION]
À utiliser avec :
- le master blueprint
- les documents d'architecture
- les documents database et security liés
