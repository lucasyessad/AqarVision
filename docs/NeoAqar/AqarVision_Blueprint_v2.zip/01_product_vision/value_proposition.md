# Proposition de valeur

## AqarPro
Permettre à une agence de :
- créer son espace professionnel
- publier vite des biens
- gérer ses collaborateurs
- recevoir et suivre des leads
- projeter une image premium

## AqarSearch
Permettre à un utilisateur de :
- rechercher facilement un bien
- comparer les annonces
- sauvegarder ses favoris
- contacter rapidement une agence

## Valeur long terme
Permettre à AqarVision de :
- structurer la donnée immobilière
- mesurer les tendances
- produire des indices de marché
- vendre des services data et premium
