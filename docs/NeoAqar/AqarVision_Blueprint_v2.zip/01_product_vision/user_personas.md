# Personas

## 1. Propriétaire / directeur d'agence
Attentes :
- rapidité
- image premium
- visibilité
- contrôle équipe
- leads qualifiés

## 2. Agent immobilier
Attentes :
- publier vite
- gérer son portefeuille
- suivre ses conversations
- travailler depuis mobile

## 3. Utilisateur final
Attentes :
- trouver rapidement
- comparer
- sauvegarder
- comprendre si le bien est sérieux

## 4. Investisseur / data consumer (future phase)
Attentes :
- tendances marché
- localisation
- prix moyen
- tension de la zone
