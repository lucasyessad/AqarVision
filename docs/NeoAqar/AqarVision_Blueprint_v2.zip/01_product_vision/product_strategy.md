# Product Strategy

## Stratégie générale
AqarVision doit avancer par couches :
1. **outil utile** (AqarPro)
2. **marketplace visible** (AqarSearch)
3. **data asset** (AqarVision Data)

## Priorités MVP
- foundations techniques
- auth
- agences
- annonces
- médias
- recherche
- contact / leads
- 4 langues
- SEO propre

## Fonctionnalités différées
- billing complet activé
- IA avancée
- recommandations
- scoring quartier
- API data

## Décision IA
Choix C validé :
- architecture IA présente
- IA simple activable plus tard
- IA avancée après traction
