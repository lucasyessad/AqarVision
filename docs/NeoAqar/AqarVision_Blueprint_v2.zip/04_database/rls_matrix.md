# RLS Matrix

## Rôles logiques
- public
- authenticated_end_user
- agency_member
- agency_admin
- super_admin

## Principes
- public lit seulement les annonces publiées
- un end_user n'accède qu'à ses favoris, notes, recherches, conversations
- un agency_member n'accède qu'à sa propre agence
- un agency_admin gère membres, branches, listings de son agence
- un super_admin a accès de supervision
