# Historisation hybride — décision finale

## SCD2
- listing_price_versions
- listing_status_versions
- agency_subscription_versions (plus tard)

## Historique événementiel
- listing_publication_history
- listing_media_history
- listing_moderation_history

## Révisions métier
- listing_revisions

## Analytics / future warehouse
- domain_events

## Sécurité / conformité
- audit_logs
