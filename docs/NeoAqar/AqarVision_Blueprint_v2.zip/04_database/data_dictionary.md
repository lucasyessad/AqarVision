# Data Dictionary

## agencies
Représente une entité professionnelle (agence ou promoteur).

## agency_branches
Branches ou bureaux liés à une agence.

## agency_memberships
Relation user <-> agency avec rôle.

## listings
Etat courant du bien immobilier.

## listing_translations
Textes localisés FR/AR/EN/ES.

## listing_media
Photos et médias du bien.

## listing_price_versions
Versions temporelles SCD2 du prix.

## listing_status_versions
Versions temporelles SCD2 du statut.

## listing_revisions
Snapshots ciblés des grosses modifications.

## domain_events
Outbox analytics / warehouse.

## audit_logs
Traçabilité sécurité / conformité.
