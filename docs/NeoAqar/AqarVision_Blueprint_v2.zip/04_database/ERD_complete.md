# ERD complet — vue simplifiée

## Domaines
- identities
- organizations
- listings
- media
- marketplace
- billing
- AI
- analytics
- audit

## Relations essentielles
users -> agency_memberships -> agencies -> branches -> listings
listings -> listing_translations
listings -> listing_media
listings -> listing_price_versions
listings -> listing_status_versions
users -> favorites / notes / saved_searches
listings -> leads -> conversations -> messages
agencies -> subscriptions
listings -> domain_events
users/agencies -> audit_logs
