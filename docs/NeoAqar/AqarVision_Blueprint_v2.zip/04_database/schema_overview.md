# Vue schématique du modèle de données

## Core identités
- users
- profiles

## Core organisation
- agencies
- agency_branches
- agency_memberships
- agency_invites

## Core immobilier
- listings
- listing_translations
- listing_media
- listing_documents

## Historique
- listing_price_versions
- listing_status_versions
- listing_revisions
- listing_publication_history
- listing_media_history
- listing_moderation_history

## Marketplace
- favorites
- notes
- saved_searches
- view_history
- leads
- conversations
- messages

## Revenus
- plans
- subscriptions
- billing_events

## IA
- ai_prompts
- ai_jobs
- ai_usage_counters
