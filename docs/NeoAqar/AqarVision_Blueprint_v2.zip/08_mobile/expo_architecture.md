# Expo Architecture

## Cible
Application mobile complète et équivalente au web.

## Capacités
- recherche
- favoris
- leads / messages
- dashboard pro
- notifications

## Shared
- domain logic
- DTO
- validations
