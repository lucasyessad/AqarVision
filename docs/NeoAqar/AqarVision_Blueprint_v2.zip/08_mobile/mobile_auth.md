# Mobile Auth

## Technique
- Supabase PKCE
- deep linking
- SecureStore
- device sessions

## Sécurité
- aucun secret sensible embarqué
- revalidation serveur pour actions critiques
