# Push Notifications

## Événements cibles
- nouveau lead
- nouveau message
- baisse de prix d'un favori
- rappel abonnement

## Stockage
- mobile_devices
- push_tokens
