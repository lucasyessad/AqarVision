# Data Flow

AqarPro -> listings -> publication -> AqarSearch -> leads -> analytics -> domain_events -> warehouse futur
