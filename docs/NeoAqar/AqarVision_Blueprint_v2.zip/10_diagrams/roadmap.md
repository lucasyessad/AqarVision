# Roadmap

## Phase 1
SaaS rentable

## Phase 2
Marketplace nationale

## Phase 3
Data company
