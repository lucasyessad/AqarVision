# Programmatic SEO

## Objectif
Créer des pages utiles et indexables par :
- wilaya
- commune
- type de bien
- transaction

## Règle
Ne jamais créer de pages SEO pauvres ou vides.
