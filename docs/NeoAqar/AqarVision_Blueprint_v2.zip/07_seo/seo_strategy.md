# SEO Strategy

## Langues
- FR
- AR
- EN
- ES

## Pages clés
- search
- listing
- agency
- wilaya
- commune
- type de bien

## Fondamentaux
- hreflang
- canonical
- sitemap index
- JSON-LD
