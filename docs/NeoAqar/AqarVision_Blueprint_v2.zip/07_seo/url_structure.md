# URL Structure

## Search
/[locale]/search

## Listing
/[locale]/l/[slug]

## Agency
/[locale]/a/[slug]

## SEO local
/[locale]/vente/[wilaya]/[property-type]
