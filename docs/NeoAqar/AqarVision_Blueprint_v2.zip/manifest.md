# Manifest — AqarVision Blueprint v2

## Fichiers racine
- 00_MASTER_BLUEPRINT_AqarVision_v2.md
- 00_CLAUDE_MASTER_CONTEXT_AqarVision_v2.md
- manifest.md

## Dossiers
- 01_product_vision/
- 02_market_research/
- 03_architecture/
- 04_database/
- 05_modules/
- 06_security/
- 07_seo/
- 08_mobile/
- 09_design/
- 10_diagrams/
