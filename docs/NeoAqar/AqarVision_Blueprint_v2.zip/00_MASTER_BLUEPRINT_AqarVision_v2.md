# AqarVision Blueprint v2

## Positionnement
AqarVision est l'écosystème global.
- **AqarPro** = CRM immobilier pour agences et promoteurs
- **AqarSearch** = marketplace publique de recherche immobilière
- Vision long terme = **data company immobilière algérienne**

## Décisions structurantes validées
- Architecture **Enterprise Monorepo**
- Base **transactionnelle OLTP** prête pour futur **OLAP**
- **Historisation hybride** :
  - SCD2 pour les dimensions critiques
  - historique événementiel pour les actions
  - domain_events pour analytics / warehouse
  - audit_logs pour sécurité / conformité
- 4 langues actives dès le départ :
  - FR
  - AR (RTL)
  - EN
  - ES
- Mobile **équivalent web**
- Activation progressive des modules coûteux
- Cybersécurité intégrée transversalement

## Ordre de lecture recommandé
1. `01_product_vision/product_strategy.md`
2. `03_architecture/global_architecture.md`
3. `04_database/ERD_complete.md`
4. `06_security/threat_model.md`
5. `05_modules/M00_Foundations.md` à `M12_CICD.md`

## Temporalité produit
### Phase 1 — SaaS rentable
AqarPro :
- onboarding agence
- mini-vitrine
- annonces
- médias
- leads
- CRM léger

### Phase 2 — Marketplace nationale
AqarSearch :
- recherche avancée
- carte
- favoris
- alertes
- SEO massif

### Phase 3 — Data Company
- historisation prix
- tendances marché
- heatmaps
- API data B2B
- modèles IA plus avancés

## Stratégie IA validée
Choix **C** :
- marketplace classique au départ
- fonctionnalités IA ajoutées progressivement
- architecture IA présente dès V1
- activation via feature flags et rentabilité

## Format des modules
Chaque module suit :
- RÔLE
- CONTEXTE
- TÂCHE
- EXEMPLE OUTPUT
- CONTRAINTES
- CRITÈRES DE SUCCÈS
- UTILISATION
