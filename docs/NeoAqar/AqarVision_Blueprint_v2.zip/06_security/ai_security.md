# AI Security

## Risques
- prompt injection
- fuite cross-tenant
- hallucination
- coût incontrôlé

## Réponses
- contexte minimal
- validation structurée
- journalisation usage
- feature flags
