# Auth Strategy

## Web
- Supabase Auth SSR
- cookies sécurisés
- middleware de session

## Mobile
- PKCE
- SecureStore
- rotation refresh token

## Rôles
- rôles globaux
- rôles agence séparés
