# Data Protection

## Principes
- minimisation des données
- séparation des secrets
- buckets privés
- audit trail
- suppression / anonymisation future-ready

## Sensibilités
- leads
- coordonnées
- documents
- historique
