# Threat Model

## Menaces prioritaires
- broken access control
- fuite inter-agence
- scraping massif
- upload malveillant
- fraude webhook Stripe
- prompt injection IA
- extraction abusive des coordonnées

## Mesures
- RLS stricte
- signed uploads
- rate limiting
- CSP
- validation côté serveur
- audit logs
