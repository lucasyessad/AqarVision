# Fonctionnalités manquantes ou à renforcer par rapport à l'ancien projet

## À renforcer
- comparateur de biens
- indicateur baisse de prix
- biens vus récemment
- reprise de recherche
- trust score agences
- reporting modération
- historisation forte

## À garder depuis l'ancien projet
- mini-vitrines agences
- branding / thèmes
- dashboard pro
- notes privées
- favoris / collections
- demandes de visite
- messagerie
