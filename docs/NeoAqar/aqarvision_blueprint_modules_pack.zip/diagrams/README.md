# [RÔLE]
Architecte logiciel, facilitateur technique.

# [CONTEXTE]
Les diagrammes servent à rendre le blueprint lisible rapidement pour les humains et pour Claude Code.

# [TÂCHE]
Centraliser :
- ERD
- flux modules
- flux data
- roadmap

# [EXEMPLE OUTPUT]
Diagrammes Mermaid clairs et maintenables.

# [CONTRAINTES]
- diagrammes cohérents avec les modules
- pas de divergence doc / schéma

# [CRITÈRES DE SUCCÈS]
- compréhension rapide du projet
- cohérence entre texte et diagrammes

# [UTILISATION]
À consulter en complément du master blueprint.
