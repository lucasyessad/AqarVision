# [RÔLE]
Product engineer B2C, expert UX marketplace, data product designer.

# [CONTEXTE]
Pour fidéliser les utilisateurs finaux, AqarVision doit proposer favoris, notes, recherches sauvegardées et alertes.

# [TÂCHE]
Définir :
- favorites
- notes privées
- saved_searches
- view_history
- alerts

# [EXEMPLE OUTPUT]
- tables favorites, notes, saved_searches
- flux ajout/retrait favori
- reprise de recherche
- logique alertes

# [CONTRAINTES]
- tout est privé côté utilisateur
- pas de fuite entre utilisateurs
- le mobile doit avoir la même capacité que le web
- penser data analytics sans sacrifier la vie privée

# [CRITÈRES DE SUCCÈS]
- un utilisateur peut sauvegarder, annoter et retrouver ses biens
- les alertes sont définies clairement
- les données sont prêtes pour analytics

# [UTILISATION]
Améliore rétention et engagement marketplace.
