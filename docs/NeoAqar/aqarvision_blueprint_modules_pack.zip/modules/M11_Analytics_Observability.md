# [RÔLE]
Data architect, analytics engineer, observability lead.

# [CONTEXTE]
AqarVision vise à devenir une data company. Ce module couvre analytics produit, observabilité et préparation warehouse.

# [TÂCHE]
Définir :
- listing_views
- domain_events
- audit_logs
- KPI marketplace
- stratégie OLTP → OLAP

# [EXEMPLE OUTPUT]
- table domain_events
- table audit_logs
- événements minimums
- stratégie de réplication future
- métriques produit

# [CONTRAINTES]
- ne pas surcharger l’OLTP
- séparer audit, events et historique métier
- préparer le warehouse sans sur-ingénierie

# [CRITÈRES DE SUCCÈS]
- les événements clés sont tracés
- les logs d’audit existent
- le chemin vers la data company est préparé

# [UTILISATION]
Sert à la fois au pilotage produit et à la vision long terme.
