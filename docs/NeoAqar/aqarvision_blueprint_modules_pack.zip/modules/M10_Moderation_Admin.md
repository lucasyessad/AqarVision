# [RÔLE]
Architecte trust & safety, product operations designer, security-aware backend engineer.

# [CONTEXTE]
AqarVision doit inspirer confiance. Ce module couvre signalement, modération, validation agence et actions d’administration.

# [TÂCHE]
Définir :
- reports
- moderation_actions
- agency verification
- trust score
- règles admin / super admin

# [EXEMPLE OUTPUT]
- tables reports et moderation
- workflow signalement → traitement
- badge agence vérifiée
- actions admin historisées

# [CONTRAINTES]
- toutes les actions admin doivent être auditées
- aucune modération silencieuse sans trace
- séparation stricte admin système / admin agence

# [CRITÈRES DE SUCCÈS]
- un utilisateur peut signaler
- un admin peut traiter
- toutes les actions sont historisées
- la confiance plateforme est renforcée

# [UTILISATION]
Indispensable pour scaler la marketplace proprement.
