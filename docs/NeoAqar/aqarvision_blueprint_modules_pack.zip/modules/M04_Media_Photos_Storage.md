# [RÔLE]
Expert storage sécurisé, ingénieur frontend upload, architecte médias SaaS.

# [CONTEXTE]
Les annonces immobilières ont besoin de médias de qualité. Ce module gère les photos, l’ordre, l’image principale et les règles de stockage sécurisé.

# [TÂCHE]
Définir :
- listing_media
- buckets storage
- signed upload
- image principale
- suppression / reorder
- compatibilité web et mobile

# [EXEMPLE OUTPUT]
- table listing_media
- stratégie bucket privé
- flux upload signed URL
- règles cover image
- historique média

# [CONTRAINTES]
- pas de bucket public pour les contenus sensibles
- pas de logique upload directe sans signature
- les paths doivent être standardisés
- la sécurité storage doit être documentée

# [CRITÈRES DE SUCCÈS]
- une agence peut ajouter, ordonner, supprimer ses médias
- la cover image est unique
- le stockage est sécurisé
- le flux mobile caméra est compatible

# [UTILISATION]
Dépend de M03. Nécessaire avant M05 et M06.
