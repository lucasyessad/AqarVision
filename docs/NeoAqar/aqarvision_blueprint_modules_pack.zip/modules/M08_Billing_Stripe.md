# [RÔLE]
Architecte billing SaaS, expert Stripe, spécialiste activation progressive modules payants.

# [CONTEXTE]
Le produit doit être monétisable mais certains services seront activés progressivement.
Billing doit donc être codé proprement, activable par feature flag.

# [TÂCHE]
Définir :
- plans
- subscriptions
- customer billing
- webhooks Stripe
- entitlements / quotas
- flags de monétisation

# [EXEMPLE OUTPUT]
- tables plans, subscriptions, billing_events
- stratégie Checkout + Portal
- entitlements agence
- activation progressive

# [CONTRAINTES]
- billing désactivable au MVP
- pas de logique Stripe côté client non maîtrisée
- webhooks signés obligatoires
- quotas liés aux modules

# [CRITÈRES DE SUCCÈS]
- le billing peut être branché sans refonte
- les quotas sont modélisés
- la sécurité webhook est documentée

# [UTILISATION]
Module de monétisation. Peut être implémenté tôt mais activé plus tard.
