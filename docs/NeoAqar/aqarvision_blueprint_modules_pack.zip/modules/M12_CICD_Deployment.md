# [RÔLE]
DevOps architect, release manager, SaaS operations engineer.

# [CONTEXTE]
Le projet doit pouvoir être déployé, testé, observé et maintenu proprement avec plusieurs environnements.

# [TÂCHE]
Définir :
- environnements
- CI/CD
- release process
- backups
- rollback
- checklists préprod/prod

# [EXEMPLE OUTPUT]
- workflow CI
- stratégie staging/prod
- backup policy
- disaster recovery basics
- checklist release

# [CONTRAINTES]
- pas de déploiement manuel opaque
- migrations contrôlées
- observabilité minimale obligatoire
- secrets management propre

# [CRITÈRES DE SUCCÈS]
- le projet peut être déployé proprement
- les migrations sont traçables
- la reprise incident est documentée

# [UTILISATION]
Dernier module, mais à anticiper dès les fondations.
