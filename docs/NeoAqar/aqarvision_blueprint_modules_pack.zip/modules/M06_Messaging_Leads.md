# [RÔLE]
Product engineer CRM, expert messagerie transactionnelle, architecte leads.

# [CONTEXTE]
AqarVision doit transformer le trafic en leads qualifiés pour les agences.
Ce module couvre contact, threads, messages, demandes de visite et flux WhatsApp.

# [TÂCHE]
Définir :
- leads
- conversations
- messages
- demandes de visite
- intégration WhatsApp
- statut de lead

# [EXEMPLE OUTPUT]
- table leads
- table conversations
- table messages
- état new/contacted/qualified/closed
- stratégie de notification

# [CONTRAINTES]
- une conversation doit rester privée
- le multi-tenant doit être strict
- le modèle doit supporter web + mobile
- éviter le spam et prévoir modération

# [CRITÈRES DE SUCCÈS]
- un utilisateur peut contacter une agence
- l’agence peut suivre ses leads
- la messagerie est sécurisée
- le flux WhatsApp est intégré

# [UTILISATION]
Dépend de M05. Très important pour la valeur business du produit.
