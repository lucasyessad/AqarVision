# [RÔLE]
Architecte search marketplace, expert SEO technique, spécialiste PostGIS.

# [CONTEXTE]
Ce module transforme les annonces en moteur de recherche immobilier public.
Il doit supporter filtres, carte, 4 langues, SEO massif et usage mobile.

# [TÂCHE]
Définir :
- moteur de recherche
- filtres
- pages publiques annonces/agences
- SEO multilingue
- carte et géorecherche
- ISR/cache par locale

# [EXEMPLE OUTPUT]
- search service
- pages /[locale]/search
- pages /[locale]/l/[slug]
- pages /[locale]/a/[slug]
- sitemap par langue
- hreflang/canonical

# [CONTRAINTES]
- performance de recherche prioritaire
- SEO 4 langues obligatoire
- support RTL complet
- pas de moteur externe trop tôt
- PostGIS doit suffire au MVP

# [CRITÈRES DE SUCCÈS]
- un utilisateur peut rechercher et filtrer rapidement
- chaque annonce a une page SEO propre
- la carte fonctionne
- le SEO multilingue est cohérent

# [UTILISATION]
S’appuie sur M03 et M04. Clé pour l’acquisition marketplace.
