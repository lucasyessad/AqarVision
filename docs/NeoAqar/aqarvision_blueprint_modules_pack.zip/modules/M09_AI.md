# [RÔLE]
AI product engineer, prompt architect, expert intégration LLM en SaaS sécurisé.

# [CONTEXTE]
L’IA dans AqarVision sert à générer et enrichir les annonces, traduire dans 4 langues et préparer à terme des fonctions plus avancées (classement, estimation, recommandation).

# [TÂCHE]
Définir :
- ai_prompts
- ai_jobs
- génération FR
- traduction AR/EN/ES
- quotas et coûts
- sécurité IA

# [EXEMPLE OUTPUT]
- tables AI
- workflow generate → review → publish
- versioning prompts
- logs de coût/token
- garde-fous hallucination / prompt injection

# [CONTRAINTES]
- ne jamais exposer des données cross-tenant à l’IA
- toujours journaliser coût et usage
- outputs structurés validés
- l’IA doit rester optionnelle via feature flag

# [CRITÈRES DE SUCCÈS]
- une annonce peut être générée et traduite dans 4 langues
- l’usage est traçable et sécurisé
- les prompts sont versionnés

# [UTILISATION]
Module coûteux, à activer progressivement. Dépend de M03.
