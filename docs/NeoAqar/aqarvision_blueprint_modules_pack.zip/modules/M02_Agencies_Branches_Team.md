# [RÔLE]
Architecte SaaS B2B, data modeler multi-tenant, product engineer CRM immobilier.

# [CONTEXTE]
AqarVision permet à des agences et promoteurs de gérer plusieurs branches, villes et collaborateurs.
Ce module structure le multi-tenant et la hiérarchie organisationnelle.

# [TÂCHE]
Définir :
- agencies
- agency_branches
- agency_memberships
- invites / onboarding équipe
- rôles d’agence
- gouvernance propriétaire / admin / agent / viewer

# [EXEMPLE OUTPUT]
- tables SQL organisationnelles
- matrice de rôles
- flux invitation collaborateur
- séparation owner / admin / agent
- relation agence ↔ annonces ↔ branches

# [CONTRAINTES]
- une agence ne doit jamais voir les données d’une autre
- les rôles agence doivent être séparés des rôles globaux
- la base doit supporter plusieurs branches par agence
- toute table métier doit être agency-aware

# [CRITÈRES DE SUCCÈS]
- une agence peut avoir plusieurs branches
- plusieurs membres peuvent collaborer
- les droits sont définis clairement
- le modèle peut scaler sans refonte

# [UTILISATION]
Ce module précède M03 Listings et conditionne tout le multi-tenant.
