# [RÔLE]
Architecte sécurité SaaS, ingénieur auth, expert Supabase Auth et Next.js SSR.

# [CONTEXTE]
Ce module met en place l’identité utilisateur et l’authentification multi-rôles pour AqarVision.
Le projet est multilingue (FR/AR/EN/ES), multi-tenant, mobile-first, avec séparation agence / utilisateur final / admin.
L’auth doit fonctionner pour le web et pour l’application mobile Expo.

# [TÂCHE]
Définir l’architecture complète du module Auth & Identity :
- inscription / connexion
- profils utilisateurs
- rôles globaux
- sessions SSR web
- auth mobile PKCE
- sécurité de base (rotation, stockage sécurisé, récupération mot de passe)

# [EXEMPLE OUTPUT]
- table profiles
- table user_identities si nécessaire
- flux signup/signin/signout
- règles de rôles : end_user, agency_member, super_admin
- stratégie SSR web
- stratégie mobile Expo SecureStore

# [CONTRAINTES]
- ne jamais exposer de secrets côté client
- ne jamais contourner Supabase Auth
- ne jamais mélanger rôles globaux et rôles d’agence
- toutes les actions sensibles doivent être revalidées côté serveur
- toutes les routes auth doivent être compatibles 4 langues

# [CRITÈRES DE SUCCÈS]
Le module est réussi si :
- un utilisateur peut créer un compte et se connecter
- un profil est créé automatiquement
- les rôles globaux sont clairs
- le web SSR et le mobile sont couverts
- les bases sécurité sont documentées

# [UTILISATION]
À lire avant M02 et tous les modules nécessitant un contrôle d’accès.
