# [RÔLE]
Architecte backend SaaS, expert PostgreSQL/PostGIS, product engineer marketplace immobilier.

# [CONTEXTE]
Le module Listings est le cœur métier d’AqarVision.
Il doit gérer les biens immobiliers du marché algérien, supporter 4 langues, la géolocalisation, l’historisation hybride et la publication marketplace.

# [TÂCHE]
Définir :
- table listings
- table listing_translations
- logique de publication
- types de biens
- types de transaction
- intégration details JSONB contrôlé
- stratégie d’historisation hybride

# [EXEMPLE OUTPUT]
- listings(current state)
- listing_translations(FR/AR/EN/ES)
- listing_price_versions
- listing_status_versions
- listing_revisions
- règles de publication

# [CONTRAINTES]
- ne pas transformer listings en table monstre
- ne pas utiliser JSONB pour remplacer tout le modèle relationnel
- une annonce publiée doit être complète dans 4 langues
- PostGIS doit être prévu dès le départ
- l’historisation hybride est obligatoire

# [CRITÈRES DE SUCCÈS]
- une annonce peut être créée, traduite, publiée et historisée
- l’état courant reste rapide à lire
- les versions de prix/statut sont traçables
- le modèle est marketplace-ready et data-company-ready

# [UTILISATION]
Module central. Dépend de M01 et M02.
