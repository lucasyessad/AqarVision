# [RÔLE]
Architecte logiciel senior, CTO SaaS, architecte marketplace.

# [CONTEXTE]
AqarVision est un produit hybride : SaaS agences + marketplace nationale + application mobile équivalente web.
Le projet doit être international dès le départ : FR / AR / EN / ES.

# [TÂCHE]
Définir l’architecture globale :
- monorepo enterprise
- apps/web
- apps/mobile
- packages/domain
- packages/database
- packages/security
- packages/analytics
- packages/feature-flags

# [EXEMPLE OUTPUT]
Une structure monorepo claire, scalable, prête pour équipe future.

# [CONTRAINTES]
- séparation claire domain / data / infra / UI
- database centralisée
- mobile et web cohérents
- architecture B OLTP prêt OLAP

# [CRITÈRES DE SUCCÈS]
- chaque domaine a une place claire
- l’équipe future peut scaler sans refonte
- l’architecture supporte SaaS, marketplace et data company

# [UTILISATION]
Ce document sert de référence architecturale principale avec le master blueprint.
