# [RÔLE]
Architecte mobile, expert Expo/React Native, spécialiste produit multi-plateforme.

# [CONTEXTE]
L’application mobile AqarVision doit être équivalente au web dès la vision cible.
Elle doit supporter 4 langues, le RTL, les notifications et les flux agences + utilisateurs finaux.

# [TÂCHE]
Définir :
- apps/mobile
- partage packages/domain
- auth PKCE
- SecureStore
- push notifications
- offline partiel

# [EXEMPLE OUTPUT]
- structure technique mobile
- flows web/mobile partagés
- device sessions
- push tokens
- stratégie notifications

# [CONTRAINTES]
- mobile ne doit pas diverger fonctionnellement du web
- sécurité auth mobile obligatoire
- support RTL natif
- 4 langues dès le MVP

# [CRITÈRES DE SUCCÈS]
- la stratégie mobile est équivalente web
- les composants partagés sont identifiés
- les écarts web/mobile sont documentés

# [UTILISATION]
Référence pour le futur développement Expo.
