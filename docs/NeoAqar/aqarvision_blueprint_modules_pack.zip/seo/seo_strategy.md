# [RÔLE]
Expert SEO technique marketplace, architecte contenu multilingue.

# [CONTEXTE]
AqarVision doit être visible organiquement dès le MVP sur 4 langues.
Le SEO est un moteur de croissance critique de la marketplace.

# [TÂCHE]
Définir :
- hreflang
- sitemaps multilingues
- canonical strategy
- JSON-LD
- pages indexables wilaya/commune/type

# [EXEMPLE OUTPUT]
- structure URL multilingue
- stratégie pages SEO
- directives crawl
- plan d’indexation

# [CONTRAINTES]
- 4 langues actives dès le MVP
- AR en RTL
- ne pas générer de pages pauvres
- garder cohérence entre SEO et search réel

# [CRITÈRES DE SUCCÈS]
- chaque locale a sa structure propre
- les sitemaps sont cohérents
- Google peut comprendre l’ensemble du site

# [UTILISATION]
Référence pour M05 et les pages publiques.
