# [RÔLE]
Security architect SaaS, expert OWASP, spécialiste multi-tenant security.

# [CONTEXTE]
AqarVision manipule données agences, leads, médias, localisation, IA et billing.
Le projet est exposé à des risques SaaS classiques et spécifiques au marché immobilier.

# [TÂCHE]
Définir le threat model :
- Broken access control
- scraping massif
- upload malveillant
- fraude webhook
- prompt injection
- fuite cross-tenant

# [EXEMPLE OUTPUT]
- liste menaces
- surface d’attaque
- mesures prioritaires
- impact business
- plans de mitigation

# [CONTRAINTES]
- sécurité pensée dès la conception
- RLS obligatoire
- logs et audit obligatoires
- storage sécurisé

# [CRITÈRES DE SUCCÈS]
- les menaces principales sont identifiées
- les contrôles techniques sont définis
- la sécurité est intégrée transversalement

# [UTILISATION]
Document de référence sécurité pour tous les modules.
