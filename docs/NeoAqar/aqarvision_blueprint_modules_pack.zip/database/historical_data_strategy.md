# [RÔLE]
Architecte data senior, spécialiste modélisation temporelle et analytique.

# [CONTEXTE]
AqarVision a validé une décision finale : historisation hybride.
L’objectif est de supporter le SaaS actuel et la future data company immobilière.

# [TÂCHE]
Définir la stratégie d’historisation :
- SCD2 pour prix et statut
- révisions métier
- historique événementiel
- domain events
- audit logs

# [EXEMPLE OUTPUT]
- listing_price_versions
- listing_status_versions
- listing_revisions
- listing_publication_history
- domain_events
- audit_logs

# [CONTRAINTES]
- ne pas tout mettre en SCD2
- séparer métier, audit et analytics
- garder l’OLTP performant

# [CRITÈRES DE SUCCÈS]
- l’état courant reste rapide à lire
- l’historique produit est exploitable
- la future data company est préparée

# [UTILISATION]
Référence officielle pour toute la couche historique.
