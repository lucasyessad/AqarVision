# Manifest

## architecture
- global_architecture.md
- monorepo_structure.md
- i18n_architecture.md
- oltp_olap_strategy.md

## database
- snapshot.sql
- ERD.md
- data_dictionary.md
- schema/00_extensions.sql
- schema/01_enums.sql
- schema/02_core_identity.sql
- schema/03_organizations.sql
- schema/04_listings.sql
- schema/05_marketplace.sql
- schema/06_billing.sql
- schema/07_ai.sql
- schema/08_analytics.sql
- history/historical_data_strategy.md
- history/scd2_model.md
- rls/rls_matrix.md
- functions/helpers.md

## security
- threat_model.md
- controls.md
- storage_security.md
- ai_security.md
- incident_response.md

## strategy
- roadmap.md
- monetization.md
- data_company_roadmap.md
- compliance_algeria.md
- finops.md

## seo
- multilingual_seo.md

## mobile
- mobile_strategy.md

## ai
- ai_architecture.md

## modules
- M00_Foundations.md
- M01_Auth_Identity.md
- M02_Agencies_Branches_Team.md
- M03_Listings_Core.md
- M04_Media_Storage.md
- M05_Marketplace_Search_SEO.md
- M06_Leads_Messaging.md
- M07_User_Favorites_Alerts.md
- M08_Billing_Stripe.md
- M09_AI_Assistant.md
- M10_Moderation_Admin.md
- M11_Analytics_Events.md
- M12_Deployment_Operations.md

## diagrams
- erd.mmd
- search_flow.mmd
- roadmap_gantt.mmd

## prompts
- claude_code_master_prompt.md