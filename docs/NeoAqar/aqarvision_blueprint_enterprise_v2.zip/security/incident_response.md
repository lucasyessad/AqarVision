# Incident Response

## Cas principaux
- fuite de données
- erreur RLS
- compromission clé API
- webhook frauduleux
- scraping massif

## Processus
1. détection
2. confinement
3. rotation secrets / désactivation features
4. analyse
5. correction
6. communication
7. post-mortem