# AI Security

## Risques
- prompt injection
- fuite de données inter-agence
- réponses non structurées
- contenu trompeur

## Contrôles
- prompts versionnés
- validation de sortie
- pas de contexte cross-tenant
- logs de consommation
- revue humaine avant publication si nécessaire