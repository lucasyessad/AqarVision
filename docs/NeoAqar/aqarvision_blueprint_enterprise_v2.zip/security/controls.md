# Security Controls

- RLS obligatoire sur toutes les tables sensibles
- politiques storage privées
- URLs signées courtes
- vérification signature Stripe
- CSP stricte
- validation Zod côté serveur
- logs d'audit
- rate limiting
- surveillance anti-scraping