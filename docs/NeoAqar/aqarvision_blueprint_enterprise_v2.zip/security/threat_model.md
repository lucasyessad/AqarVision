# Threat Model

## Menaces principales
- escalade de privilèges inter-agence
- scraping massif des annonces
- upload de fichiers malveillants
- webhook forgé
- prompt injection
- fuite de données privées

## Surface d'attaque
- web
- mobile
- storage
- billing
- IA
- recherche géospatiale