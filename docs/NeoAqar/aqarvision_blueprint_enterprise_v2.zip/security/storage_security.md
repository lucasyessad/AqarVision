# Storage Security

## Buckets
- listing-images : privé
- agency-documents : privé
- temp-uploads : privé

## Règles
- aucun bucket public pour documents sensibles
- upload uniquement via signed upload URLs
- contrôle MIME et taille
- suppression logique + rétention définie