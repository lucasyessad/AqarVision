# Multilingual SEO

## Règles
- hreflang fr/ar/en/es
- x-default
- sitemap par langue
- canonical par locale
- slugs uniques par locale
- JSON-LD pour annonces et agences

## Pages cibles
- pages annonces
- pages agences
- pages wilayas
- pages communes
- pages transaction + type