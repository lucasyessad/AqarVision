# FinOps

## Coûts à surveiller
- Supabase DB
- Storage
- bande passante images
- IA
- push mobile
- maps premium si activées

## Règles
- commencer avec solutions gratuites ou peu coûteuses
- activer les modules coûteux seulement après rentabilité
- monitorer les coûts mensuellement