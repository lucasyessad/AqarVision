# Product Roadmap

## Phase 1
SaaS agences rentable :
- auth
- agences
- annonces
- médias
- mini-sites
- recherche publique

## Phase 2
Marketplace nationale :
- favoris
- alertes
- messagerie
- mobile complet
- SEO massif

## Phase 3
Data company :
- warehouse
- indices prix
- API data B2B
- dashboards investisseurs