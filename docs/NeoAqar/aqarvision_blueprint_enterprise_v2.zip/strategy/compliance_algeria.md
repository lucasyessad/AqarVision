# Compliance Algeria

## À cadrer
- données personnelles
- responsabilité sur les annonces
- conservation des leads
- traitement des pièces justificatives
- conditions générales agences
- politique de modération

## Approche recommandée
Adopter une discipline de niveau RGPD-like même si le cadre local est moins mature.