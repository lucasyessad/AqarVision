# Data Company Roadmap

## Pré-requis
- données propres
- historisation fiable
- événements métier
- géolocalisation précise
- gouvernance data

## Produits futurs
- indice immobilier par wilaya
- indice par commune
- temps moyen de vente
- tension locative
- heatmaps d'intérêt
- API data partenaires