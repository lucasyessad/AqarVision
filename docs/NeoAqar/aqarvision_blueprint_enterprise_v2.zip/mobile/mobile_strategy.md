# Mobile Strategy

## Architecture
- Expo React Native
- partage logique métier avec packages/domain
- auth PKCE
- SecureStore
- push notifications
- cache local partiel

## Scope
Mobile équivalent web :
- dashboard agence
- création annonce
- recherche
- favoris
- messages
- analytics simples