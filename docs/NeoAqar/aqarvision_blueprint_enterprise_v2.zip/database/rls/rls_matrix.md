# RLS Matrix

## Roles
- public
- authenticated_end_user
- agency_member
- super_admin

## Examples
- public: select published listings only
- authenticated_end_user: own favorites, own notes, own alerts
- agency_member: CRUD own agency listings, own leads, own messages in agency scope
- super_admin: moderation and supervision