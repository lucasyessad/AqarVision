# ERD

```mermaid
erDiagram
  USERS ||--o{ AGENCY_MEMBERSHIPS : has
  AGENCIES ||--o{ AGENCY_BRANCHES : has
  AGENCIES ||--o{ AGENCY_MEMBERSHIPS : has
  AGENCIES ||--o{ LISTINGS : owns
  AGENCY_BRANCHES ||--o{ LISTINGS : hosts

  LISTINGS ||--o{ LISTING_TRANSLATIONS : translated
  LISTINGS ||--o{ LISTING_MEDIA : has
  LISTINGS ||--o{ LISTING_DOCUMENTS : has
  LISTINGS ||--o{ LISTING_PRICE_VERSIONS : tracks
  LISTINGS ||--o{ LISTING_STATUS_VERSIONS : tracks
  LISTINGS ||--o{ LISTING_REVISIONS : revised
  LISTINGS ||--o{ LEADS : receives

  USERS ||--o{ FAVORITES : saves
  USERS ||--o{ SAVED_SEARCHES : stores
  USERS ||--o{ NOTES : writes
  LEADS ||--|| CONVERSATIONS : opens
  CONVERSATIONS ||--o{ MESSAGES : contains

  AGENCIES ||--o{ SUBSCRIPTIONS : has
  PLANS ||--o{ SUBSCRIPTIONS : powers
  AGENCIES ||--o{ AI_JOBS : consumes
  LISTINGS ||--o{ AI_JOBS : uses

  LISTINGS ||--o{ DOMAIN_EVENTS : emits
  AGENCIES ||--o{ AUDIT_LOGS : generates
```