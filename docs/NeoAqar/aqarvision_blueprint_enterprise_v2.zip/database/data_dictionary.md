# Data Dictionary

## listings
Table courante des biens immobiliers. Contient l'état actuel pour l'OLTP.

## listing_translations
Titres, descriptions et slugs par locale : fr, ar, en, es.

## listing_price_versions
Historique SCD2 du prix des biens.

## listing_status_versions
Historique SCD2 du statut des biens.

## listing_revisions
Snapshots ciblés des modifications métier importantes.

## domain_events
Outbox analytique pour future réplication vers warehouse.

## audit_logs
Traçabilité sécurité et conformité.