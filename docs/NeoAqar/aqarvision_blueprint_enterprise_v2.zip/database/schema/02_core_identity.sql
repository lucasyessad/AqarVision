create table users (
  id uuid primary key,
  full_name text,
  avatar_url text,
  phone text,
  role user_role not null default 'end_user',
  preferred_locale text not null default 'fr',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table mobile_devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  platform text not null,
  app_version text,
  device_identifier text,
  created_at timestamptz not null default now()
);

create table push_tokens (
  id uuid primary key default gen_random_uuid(),
  device_id uuid not null references mobile_devices(id) on delete cascade,
  token text not null,
  provider text not null default 'expo',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);