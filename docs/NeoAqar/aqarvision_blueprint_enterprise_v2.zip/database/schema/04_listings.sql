create table listings (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  branch_id uuid references agency_branches(id),
  current_price numeric(14,2) not null,
  currency text not null default 'DZD',
  current_status listing_status not null default 'draft',
  listing_type listing_type not null,
  property_type property_type not null,
  surface_m2 numeric(10,2),
  rooms integer,
  bathrooms integer,
  wilaya_code text not null,
  commune_id bigint,
  location geography(point, 4326),
  details jsonb not null default '{}'::jsonb,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_listings_agency_id on listings(agency_id);
create index idx_listings_status on listings(current_status);
create index idx_listings_type on listings(listing_type, property_type);
create index idx_listings_wilaya on listings(wilaya_code);
create index idx_listings_location_gist on listings using gist(location);

create table listing_translations (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  locale text not null check (locale in ('fr','ar','en','es')),
  title text not null,
  description text not null,
  slug text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (listing_id, locale),
  unique (locale, slug)
);

create table listing_media (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  storage_path text not null,
  is_cover boolean not null default false,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table listing_documents (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  document_type document_type not null,
  storage_path text not null,
  created_at timestamptz not null default now()
);

create table listing_price_versions (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  price numeric(14,2) not null,
  currency text not null default 'DZD',
  valid_from timestamptz not null,
  valid_to timestamptz,
  is_current boolean not null default true,
  changed_by_user_id uuid references users(id),
  changed_reason text,
  created_at timestamptz not null default now(),
  constraint chk_price_validity check (valid_to is null or valid_to > valid_from)
);

create unique index idx_listing_price_current on listing_price_versions(listing_id) where is_current = true;

create table listing_status_versions (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  status listing_status not null,
  valid_from timestamptz not null,
  valid_to timestamptz,
  is_current boolean not null default true,
  changed_by_user_id uuid references users(id),
  changed_reason text,
  created_at timestamptz not null default now(),
  constraint chk_status_validity check (valid_to is null or valid_to > valid_from)
);

create unique index idx_listing_status_current on listing_status_versions(listing_id) where is_current = true;

create table listing_revisions (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  revision_number integer not null,
  change_type text not null,
  changed_by_user_id uuid references users(id),
  payload jsonb not null,
  created_at timestamptz not null default now(),
  unique (listing_id, revision_number)
);

create table listing_publication_history (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  action text not null,
  created_by_user_id uuid references users(id),
  created_at timestamptz not null default now()
);

create table listing_media_history (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  media_id uuid,
  action text not null,
  metadata jsonb,
  changed_by_user_id uuid references users(id),
  created_at timestamptz not null default now()
);

create table listing_moderation_history (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  action text not null,
  reason text,
  moderator_user_id uuid references users(id),
  payload jsonb,
  created_at timestamptz not null default now()
);