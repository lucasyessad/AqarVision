create table listing_views (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  user_id uuid references users(id),
  locale text,
  viewed_at timestamptz not null default now()
);

create table domain_events (
  id uuid primary key default gen_random_uuid(),
  aggregate_type text not null,
  aggregate_id uuid not null,
  event_name text not null,
  agency_id uuid references agencies(id),
  actor_user_id uuid references users(id),
  payload jsonb not null,
  created_at timestamptz not null default now(),
  processed_at timestamptz
);

create table audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_user_id uuid references users(id),
  agency_id uuid references agencies(id),
  entity_type text not null,
  entity_id uuid,
  action text not null,
  before_payload jsonb,
  after_payload jsonb,
  created_at timestamptz not null default now()
);