# SCD2 Model

## Colonnes standard
- valid_from
- valid_to
- is_current

## Règle
Une seule ligne courante par entité et par dimension historisée.

## Usage
- prix
- statut
- abonnement agence

## Requêtes possibles
- prix à une date donnée
- statut à une date donnée
- durée d'un prix
- durée d'un statut