# Historical Data Strategy

AqarVision utilise un modèle hybride :

## SCD2
Pour les dimensions métier critiques :
- listing_price_versions
- listing_status_versions
- agency_subscription_versions

## Event history
Pour les actions métier :
- listing_publication_history
- listing_media_history
- listing_moderation_history

## Révisions métier
- listing_revisions

## Data layer
- domain_events

## Sécurité
- audit_logs

## Rationale
- lecture OLTP rapide via la table courante
- historique fiable pour analytics
- base exploitable pour futur indice immobilier