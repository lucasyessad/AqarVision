-- AqarVision snapshot.sql
-- Snapshot simplifié du schéma principal.
-- Le fichier complet est à enrichir via migrations versionnées.

\i schema/00_extensions.sql
\i schema/01_enums.sql
\i schema/02_core_identity.sql
\i schema/03_organizations.sql
\i schema/04_listings.sql
\i schema/05_marketplace.sql
\i schema/06_billing.sql
\i schema/07_ai.sql
\i schema/08_analytics.sql