# OLTP / OLAP Strategy

## Architecture B
Base transactionnelle séparée conceptuellement d'un futur entrepôt analytique.

### OLTP
- listings
- agencies
- memberships
- leads
- messages
- subscriptions
- ai_jobs
- listing_price_versions
- listing_status_versions

### Bridge
- domain_events (outbox)
- audit_logs

### Futur OLAP
- agrégats par wilaya / commune / quartier
- indicateurs prix
- vitesse de vente/location
- segmentation demande/offre
- dashboards investisseurs