# Global Architecture

AqarVision combine quatre couches :

1. **Produit Pro**
   - onboarding agence
   - branches multi-villes
   - multi-agents
   - création et publication d'annonces
   - mini-vitrines agence
   - leads, messages, analytics

2. **Produit Public**
   - moteur de recherche
   - pages annonces
   - pages agences
   - carte
   - favoris
   - alertes
   - messagerie

3. **Couche Data**
   - base transactionnelle Supabase/Postgres
   - historisation hybride
   - outbox `domain_events`
   - préparation réplication vers entrepôt analytique

4. **Couche Sécurité/Gouvernance**
   - RLS multi-tenant
   - audit trail
   - politiques de rétention
   - monitoring sécurité
   - conformité locale

## Principes
- server components par défaut côté web
- server actions pour mutations simples
- route handlers pour callbacks externes
- logique métier partagée dans `packages/domain`
- modèle de données centralisé dans `packages/database`
- aucune logique SQL dispersée dans les features UI