# i18n Architecture

## Locales
- fr
- ar
- en
- es

## Routing
Toutes les routes publiques et privées sont sous `/{locale}/...`.

## Règles
- `dir="rtl"` uniquement pour l'arabe
- fallback de contenu : locale demandée -> fr -> en
- les annonces sont publiables uniquement si les 4 locales sont présentes
  ou si les 3 locales secondaires ont été générées via IA et validées

## Impacts techniques
- table `listing_translations`
- sitemap par langue
- hreflang partout
- slugs uniques par locale
- tests UI RTL obligatoires