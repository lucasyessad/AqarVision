# Monorepo Structure

```text
aqarvision/
  apps/
    web/
    mobile/
  packages/
    domain/
    database/
    security/
    feature-flags/
    analytics/
    ui-web/
    ui-mobile/
    config/
    api-client/
  docs/
```

## Pourquoi cette structure
- séparer les responsabilités
- permettre la montée en équipe
- partager la logique métier entre web et mobile
- centraliser la couche data et la sécurité