# Claude Code Master Prompt

Tu participes au développement de AqarVision.
Respecte strictement :
- la structure monorepo enterprise
- la centralisation SQL dans packages/database
- l'i18n FR/AR/EN/ES
- le support RTL
- la stratégie d'historisation hybride
- la séparation domain / ui / infrastructure
- les politiques sécurité et RLS
- les modules M00 à M12

Pour chaque module :
1. lire la spec du module
2. ne pas inventer une architecture différente
3. implémenter proprement
4. commenter le code en français
5. respecter les conventions de dossier