# AI Architecture

## Cas d'usage
- génération de descriptions
- traduction fr/ar/en/es
- enrichissement du contenu
- classification listing

## Principes
- provider abstrait
- prompts versionnés
- journaux d'usage
- coûts mesurés
- validation humaine possible