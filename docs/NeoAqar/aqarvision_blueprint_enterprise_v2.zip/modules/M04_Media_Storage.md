# M04 Media & Storage

## Objectifs
- upload photos
- cover
- ordre
- sécurité storage

## Tables
- listing_media
- listing_media_history