# M09 AI Assistant

## Objectifs
- rédaction
- traduction 4 langues
- enrichissement
- classification

## Tables
- ai_prompts
- ai_jobs