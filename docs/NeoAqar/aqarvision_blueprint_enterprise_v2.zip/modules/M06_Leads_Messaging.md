# M06 Leads & Messaging

## Objectifs
- demandes de contact
- conversations
- messages
- notifications

## Tables
- leads
- conversations
- messages