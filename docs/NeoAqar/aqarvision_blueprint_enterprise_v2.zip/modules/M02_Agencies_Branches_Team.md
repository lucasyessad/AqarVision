# M02 Agencies, Branches & Team

## Objectifs
- agences
- branches multi-villes
- multi-agents
- rôles

## Tables
- agencies
- agency_branches
- agency_memberships