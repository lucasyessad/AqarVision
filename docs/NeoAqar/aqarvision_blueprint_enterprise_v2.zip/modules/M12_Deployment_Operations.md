# M12 Deployment & Operations

## Objectifs
- CI/CD
- monitoring
- backups
- incident response
- FinOps

## Livrables
- pipelines
- alerting
- checklists pré-production