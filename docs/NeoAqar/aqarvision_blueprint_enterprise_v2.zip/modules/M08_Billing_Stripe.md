# M08 Billing & Stripe

## Objectifs
- plans
- abonnements
- portails de paiement
- quotas

## Tables
- plans
- subscriptions
- agency_subscription_versions
- feature_flags
- agency_feature_entitlements