# M05 Marketplace Search & SEO

## Objectifs
- recherche par filtres
- carte
- pages SEO multilingues
- pages agences publiques

## Tables
- listings
- listing_translations
- listing_views
- favorites
- saved_searches

## Points techniques
- PostGIS
- ISR
- hreflang
- sitemap