# M00 Foundations

## Objectifs
- monorepo enterprise
- i18n 4 langues
- design system
- conventions de code
- stack Supabase/Next/Expo
- feature flags initiaux

## Livrables
- structure repo
- convention dossiers
- config i18n
- design tokens
- setup observabilité