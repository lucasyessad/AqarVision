# M07 User Favorites & Alerts

## Objectifs
- favoris
- notes
- recherches sauvegardées
- alertes

## Tables
- favorites
- notes
- saved_searches