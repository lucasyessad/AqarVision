# M03 Listings Core

## Objectifs
- créer et gérer les annonces
- multi-langue
- workflow draft/publication
- historisation hybride

## Tables
- listings
- listing_translations
- listing_documents
- listing_price_versions
- listing_status_versions
- listing_revisions
- listing_publication_history

## Critères d'acceptation
- publication impossible sans contenu 4 langues validé
- historique prix/statut cohérent
- slugs uniques par locale