# M11 Analytics & Events

## Objectifs
- vues
- événements métier
- préparation warehouse

## Tables
- listing_views
- domain_events
- audit_logs