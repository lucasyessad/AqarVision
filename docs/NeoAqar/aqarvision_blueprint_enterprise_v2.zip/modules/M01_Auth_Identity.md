# M01 Auth & Identity

## Objectifs
- inscription / connexion
- profils utilisateurs
- rôles
- sessions web et mobile

## Tables
- users
- mobile_devices
- push_tokens

## Sécurité
- auth Supabase SSR
- PKCE mobile
- rotation tokens