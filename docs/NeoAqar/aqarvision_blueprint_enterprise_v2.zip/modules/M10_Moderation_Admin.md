# M10 Moderation & Admin

## Objectifs
- signalements
- actions admin
- badge vérifié
- confiance plateforme

## Tables
- listing_moderation_history
- audit_logs