
Future analytics

- property price index
- average selling time
- rental demand
- price evolution by city
