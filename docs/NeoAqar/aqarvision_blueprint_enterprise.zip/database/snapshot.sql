
create table listings (
 id uuid primary key,
 agency_id uuid,
 property_type text,
 listing_type text,
 current_price numeric,
 surface_m2 numeric,
 rooms integer,
 wilaya text,
 created_at timestamptz default now()
);

create table listing_price_versions (
 id uuid primary key,
 listing_id uuid,
 price numeric,
 valid_from timestamptz,
 valid_to timestamptz,
 is_current boolean
);

create table domain_events (
 id uuid primary key,
 aggregate_type text,
 aggregate_id uuid,
 event_name text,
 payload jsonb,
 created_at timestamptz default now()
);
