
listings -> main property table
listing_price_versions -> SCD2 price history
domain_events -> analytics event stream
