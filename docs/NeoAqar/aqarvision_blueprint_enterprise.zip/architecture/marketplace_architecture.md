
# Marketplace Architecture

Search filters
- price
- type
- location
- rooms
- surface

Database
PostGIS used for geo queries
