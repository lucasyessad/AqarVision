
# System Architecture

Frontend
- Next.js App Router
- SSR / ISR
- Multi-language routing

Backend
- Supabase
- PostgreSQL + PostGIS

Mobile
- Expo React Native

Services
- AI service for listing generation
- media storage
- search service
