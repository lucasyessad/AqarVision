
# Mobile Architecture

Expo React Native application

Features
- listing search
- map search
- messaging
- saved searches
- favorites
