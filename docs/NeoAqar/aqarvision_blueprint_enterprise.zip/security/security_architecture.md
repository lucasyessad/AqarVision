
# Security Architecture

Security measures

- Row Level Security
- audit logs
- rate limiting
- secret management
- OWASP protections
