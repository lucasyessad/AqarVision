
# AqarVision Enterprise Blueprint

Architecture blueprint for a SaaS + Marketplace + Data Company real estate platform targeting the Algerian market.

## Stack
- Next.js 14 (App Router)
- Supabase (Postgres + Auth + Storage)
- Tailwind + Shadcn
- PostGIS
- Expo Mobile

## Key Concepts
- Multi-tenant SaaS
- Marketplace search engine
- Hybrid historical data model (SCD2 + event history)
- Internationalization (FR / AR / EN / ES)
- Data-company ready architecture
