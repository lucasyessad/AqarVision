
Phase 1 SaaS
Phase 2 Marketplace
Phase 3 Mobile
Phase 4 Data analytics platform
