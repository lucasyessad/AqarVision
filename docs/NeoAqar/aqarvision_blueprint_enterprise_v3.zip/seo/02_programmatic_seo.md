# Programmatic SEO

Pages cibles :
- transaction + type + wilaya
- transaction + type + commune
- pages agence
- pages listing