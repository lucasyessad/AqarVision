# Multilingual SEO

- hreflang fr/ar/en/es
- x-default
- sitemap par langue
- canonical par locale
- JSON-LD annonces/agences