# Module Execution Template

Pour exécuter un module :
1. lire la spec du module
2. identifier tables concernées
3. identifier validations
4. identifier sécurité/RLS
5. implémenter UI
6. implémenter logique métier
7. tester
8. documenter