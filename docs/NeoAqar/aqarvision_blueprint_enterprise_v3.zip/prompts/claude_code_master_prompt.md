# Claude Code Master Prompt

Respecter strictement :
- la structure monorepo enterprise
- la centralisation SQL dans packages/database
- les 4 langues fr/ar/en/es
- le support RTL
- l'historisation hybride
- la séparation domain/ui/infrastructure
- les politiques RLS
- les modules M00 à M12