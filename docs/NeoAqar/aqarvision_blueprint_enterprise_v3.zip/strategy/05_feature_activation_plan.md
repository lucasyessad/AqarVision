# Feature Activation Plan

Activables progressivement :
- billing avancé
- IA premium
- analytics premium
- push premium
- maps premium