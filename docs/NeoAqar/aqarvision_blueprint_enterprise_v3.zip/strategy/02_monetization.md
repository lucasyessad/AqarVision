# Monetization

Revenus :
- abonnements agence
- boost annonces
- sponsorisation
- thèmes premium
- produits data futurs