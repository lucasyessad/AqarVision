# FinOps

Surveiller :
- base de données
- storage
- bande passante
- IA
- notifications push
- maps premium