# Data Company Roadmap

Produits futurs :
- indice prix par wilaya/commune
- temps moyen de vente
- tension locative
- heatmaps
- API B2B