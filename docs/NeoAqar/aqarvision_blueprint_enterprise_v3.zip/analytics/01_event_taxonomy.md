# Event Taxonomy

Exemples :
- listing_created
- listing_published
- price_changed
- lead_received
- favorite_added
- search_saved