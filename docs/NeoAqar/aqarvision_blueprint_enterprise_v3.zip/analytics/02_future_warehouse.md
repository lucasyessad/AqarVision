# Future Warehouse

Objectif :
- répliquer domain_events
- produire agrégats par zone
- alimenter dashboards et produits data