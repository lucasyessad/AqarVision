# Push, Offline & Auth

- push via Expo dans un premier temps
- cache local partiel
- reconnexion transparente
- gestion sécurisée des tokens