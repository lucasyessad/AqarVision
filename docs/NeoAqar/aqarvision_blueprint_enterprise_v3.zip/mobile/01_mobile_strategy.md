# Mobile Strategy

- Expo React Native
- parité fonctionnelle web
- auth PKCE
- SecureStore
- push notifications