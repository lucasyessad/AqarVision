# Mobile Full Parity

L'application mobile doit couvrir les mêmes capacités que le web.

## Côté pro
- dashboard
- annonces
- photos caméra
- leads/messages
- analytics simples

## Côté public
- recherche
- carte
- annonces
- favoris
- alertes
- messagerie