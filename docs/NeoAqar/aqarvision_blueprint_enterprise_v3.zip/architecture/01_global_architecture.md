# Global Architecture

AqarVision est organisé comme un système en 4 couches :

## 1. Couche produit professionnel
- gestion multi-agences / multi-branches
- création et gestion d'annonces
- gestion médias
- leads et messagerie
- analytics agence
- IA de rédaction, traduction et enrichissement

## 2. Couche marketplace publique
- recherche immobilière multi-critères
- pages annonces et agences
- favoris, notes, alertes
- carte
- SEO programmatique
- parcours mobile-first

## 3. Couche data
- base transactionnelle Supabase/Postgres
- historisation hybride
- outbox `domain_events`
- préparation réplication future vers entrepôt analytique

## 4. Couche sécurité et gouvernance
- RLS multi-tenant
- audit trail
- gestion secrets
- politiques de rétention
- conformité et gouvernance data

## Principes
- modular monolith orienté domaines
- monorepo enterprise
- SQL centralisé dans `packages/database`
- logique métier partagée web/mobile
- aucune logique SQL dans les composants UI