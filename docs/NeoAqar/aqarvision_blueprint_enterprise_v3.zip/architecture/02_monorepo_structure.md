# Monorepo Structure

```text
aqarvision/
  apps/
    web/
    mobile/
  packages/
    domain/
    database/
    security/
    feature-flags/
    analytics/
    ui-web/
    ui-mobile/
    api-client/
    config/
  docs/
```

## Rôle des packages
- `domain` : logique métier pure, DTO, policies métier
- `database` : schéma, migrations, RLS, fonctions, triggers, types
- `security` : politiques, patterns et contrôles de sécurité
- `feature-flags` : activation progressive de modules
- `analytics` : taxonomie événements et préparation warehouse
- `ui-web` : design system web
- `ui-mobile` : design system mobile

## Pourquoi ce choix
- séparation claire des responsabilités
- évolutivité équipe
- partage web/mobile
- maintenabilité