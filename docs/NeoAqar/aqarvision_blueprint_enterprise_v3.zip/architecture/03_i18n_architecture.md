# i18n Architecture

## Locales actives
- fr
- ar
- en
- es

## Routing
Toutes les routes applicatives sont encapsulées sous `/{locale}/...`.

## Règles
- `dir="rtl"` uniquement pour l'arabe
- les slugs d'annonces sont uniques par locale
- fallback de contenu : locale demandée -> fr -> en
- les annonces publiables doivent avoir 4 traductions disponibles

## Impacts
- `listing_translations`
- SEO `hreflang`
- sitemap par langue
- tests UI RTL obligatoires