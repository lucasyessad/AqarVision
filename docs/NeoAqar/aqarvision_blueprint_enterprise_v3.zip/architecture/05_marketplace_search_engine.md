# Marketplace Search Engine

## Entrées
- listing_type
- property_type
- wilaya
- commune
- quartier
- prix min/max
- surface min/max
- pièces
- filtres details (ascenseur, citerne, meublé)

## Exécution
- Postgres + PostGIS
- index GiST sur location
- index composites sur statut/type/wilaya
- filtres JSONB ciblés pour details

## Sorties
- cards
- map markers
- slugs localisés
- snippets SEO