# OLTP / OLAP Strategy

## Architecture B
Le système sépare conceptuellement :
- OLTP : transactionnel (Supabase/Postgres)
- OLAP : analytique futur (warehouse séparé)

## OLTP
Optimisé pour :
- CRUD rapide
- dashboard agence
- recherche marketplace
- historique métier

## Outbox
`domain_events` sert de bridge vers l'analytics.

## Futur OLAP
Permettra :
- indice de prix
- heatmaps
- temps moyen de vente/location
- dashboards investisseurs