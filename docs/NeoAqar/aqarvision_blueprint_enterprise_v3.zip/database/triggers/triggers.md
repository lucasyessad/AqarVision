# Triggers

Triggers recommandés :
- mise à jour `updated_at`
- clôture automatique des lignes SCD2 courantes
- émission domain_events lors des changements critiques
- journalisation audit pour actions sensibles