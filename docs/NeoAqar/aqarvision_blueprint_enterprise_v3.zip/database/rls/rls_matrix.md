# RLS Matrix

## Roles
- public
- authenticated_end_user
- agency_member
- super_admin

## Listings
- public : select seulement si published
- agency_member : CRUD seulement si membre de l'agence
- super_admin : supervision selon procédures admin

## Favorites / Notes / Saved Searches
- utilisateur connecté : accès uniquement à ses propres données

## Leads / Conversations / Messages
- agence propriétaire ou participant