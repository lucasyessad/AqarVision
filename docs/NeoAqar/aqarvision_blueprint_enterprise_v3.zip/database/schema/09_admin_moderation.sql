create table reports (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid references listings(id) on delete cascade,
  reporter_user_id uuid references users(id),
  reason text not null,
  status text not null default 'new',
  created_at timestamptz not null default now()
);

create table moderation_actions (
  id uuid primary key default gen_random_uuid(),
  report_id uuid references reports(id) on delete cascade,
  moderator_user_id uuid references users(id),
  action text not null,
  notes text,
  created_at timestamptz not null default now()
);