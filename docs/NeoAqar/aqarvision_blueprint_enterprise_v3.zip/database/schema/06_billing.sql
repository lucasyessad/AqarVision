create table plans (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  max_listings integer,
  max_ai_generations integer,
  price_monthly numeric(12,2),
  is_active boolean not null default true
);

create table subscriptions (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  plan_id uuid not null references plans(id),
  status subscription_status not null,
  stripe_customer_id text,
  stripe_subscription_id text,
  started_at timestamptz,
  current_period_end timestamptz
);

create table feature_flags (
  key text primary key,
  is_enabled boolean not null default false,
  description text
);

create table agency_feature_entitlements (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  feature_key text not null references feature_flags(key),
  is_enabled boolean not null default false,
  created_at timestamptz not null default now(),
  unique(agency_id, feature_key)
);