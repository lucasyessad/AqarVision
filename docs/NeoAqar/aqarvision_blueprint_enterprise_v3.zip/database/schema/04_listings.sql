create table listings (
  id uuid primary key default gen_random_uuid(),
  agency_id uuid not null references agencies(id) on delete cascade,
  branch_id uuid references agency_branches(id),
  current_price numeric(14,2) not null,
  currency text not null default 'DZD',
  current_status listing_status not null default 'draft',
  listing_type listing_type not null,
  property_type property_type not null,
  surface_m2 numeric(10,2),
  rooms integer,
  bathrooms integer,
  wilaya_code text not null,
  commune_id bigint,
  location geography(point, 4326),
  details jsonb not null default '{}'::jsonb,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_listings_agency_id on listings(agency_id);
create index idx_listings_status on listings(current_status);
create index idx_listings_type on listings(listing_type, property_type);
create index idx_listings_wilaya on listings(wilaya_code);
create index idx_listings_location_gist on listings using gist(location);

create table listing_translations (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  locale text not null check (locale in ('fr','ar','en','es')),
  title text not null,
  description text not null,
  slug text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (listing_id, locale),
  unique (locale, slug)
);

create table listing_media (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  storage_path text not null,
  is_cover boolean not null default false,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table listing_documents (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references listings(id) on delete cascade,
  document_type document_type not null,
  storage_path text not null,
  created_at timestamptz not null default now()
);