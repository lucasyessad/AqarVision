# Data Dictionary

## users
Utilisateurs finaux et administrateurs système.

## agencies
Entités professionnelles propriétaires des annonces.

## agency_branches
Implantations multi-villes des agences.

## listings
Table courante des biens, optimisée OLTP.

## listing_translations
Contenus localisés fr/ar/en/es.

## listing_price_versions
Historique SCD2 du prix.

## listing_status_versions
Historique SCD2 du statut.

## listing_revisions
Snapshots métier ciblés.

## domain_events
Outbox analytique.

## audit_logs
Logs sécurité/conformité.