# ERD

Voir `diagrams/erd.mmd` pour la version Mermaid complète.