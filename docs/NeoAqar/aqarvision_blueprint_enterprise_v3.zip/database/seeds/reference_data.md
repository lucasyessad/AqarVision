# Reference Data

Données de référence à prévoir :
- wilayas d'Algérie
- communes
- éventuellement quartiers normalisés plus tard
- plans de pricing par défaut
- feature flags initiaux