# AI Architecture

Cas d'usage :
- génération d'annonces
- traduction FR/AR/EN/ES
- enrichissement
- classification