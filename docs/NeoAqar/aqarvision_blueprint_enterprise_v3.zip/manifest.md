# Manifest V3

## architecture
- architecture/01_global_architecture.md
- architecture/02_monorepo_structure.md
- architecture/03_i18n_architecture.md
- architecture/04_oltp_olap_strategy.md
- architecture/05_marketplace_search_engine.md
- architecture/06_mobile_full_parity.md

## database
- database/snapshot.sql
- database/ERD.md
- database/data_dictionary.md
- database/schema/00_extensions.sql
- database/schema/01_enums.sql
- database/schema/02_identity.sql
- database/schema/03_organizations.sql
- database/schema/04_listings.sql
- database/schema/05_marketplace.sql
- database/schema/06_billing.sql
- database/schema/07_ai.sql
- database/schema/08_analytics.sql
- database/schema/09_admin_moderation.sql
- database/history/01_historical_data_strategy.md
- database/history/02_scd2_prices.sql
- database/history/03_scd2_statuses.sql
- database/history/04_listing_revisions.sql
- database/history/05_publication_media_moderation_history.sql
- database/history/06_domain_events_audit_logs.sql
- database/rls/rls_matrix.md
- database/rls/01_policy_principles.sql
- database/functions/helpers.md
- database/triggers/triggers.md
- database/seeds/reference_data.md

## security
- security/01_threat_model.md
- security/02_security_controls.md
- security/03_storage_security.md
- security/04_ai_security.md
- security/05_webhook_security.md
- security/06_incident_response.md
- security/07_preprod_checklist.md

## strategy
- strategy/01_product_roadmap.md
- strategy/02_monetization.md
- strategy/03_data_company_roadmap.md
- strategy/04_finops.md
- strategy/05_feature_activation_plan.md

## governance
- governance/01_data_governance.md
- governance/02_data_retention.md
- governance/03_compliance_algeria.md
- governance/04_business_continuity.md

## seo
- seo/01_multilingual_seo.md
- seo/02_programmatic_seo.md

## mobile
- mobile/01_mobile_strategy.md
- mobile/02_push_offline_auth.md

## ai
- ai/01_ai_architecture.md
- ai/02_prompt_lifecycle.md

## analytics
- analytics/01_event_taxonomy.md
- analytics/02_future_warehouse.md

## modules
- modules/M00_Foundations.md
- modules/M01_Auth_Identity.md
- modules/M02_Agencies_Branches_Team.md
- modules/M03_Listings_Core.md
- modules/M04_Media_Storage.md
- modules/M05_Marketplace_Search_SEO.md
- modules/M06_Leads_Messaging.md
- modules/M07_User_Favorites_Alerts.md
- modules/M08_Billing_Stripe.md
- modules/M09_AI_Assistant.md
- modules/M10_Moderation_Admin.md
- modules/M11_Analytics_Events.md
- modules/M12_Deployment_Operations.md

## diagrams
- diagrams/erd.mmd
- diagrams/search_flow.mmd
- diagrams/history_flow.mmd
- diagrams/roadmap_gantt.mmd

## prompts
- prompts/claude_code_master_prompt.md
- prompts/module_execution_template.md