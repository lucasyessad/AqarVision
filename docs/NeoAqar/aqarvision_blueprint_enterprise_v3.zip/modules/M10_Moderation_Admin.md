# M10 Moderation & Admin

Tables :
- reports
- moderation_actions
- audit_logs