# M08 Billing & Stripe

Tables :
- plans
- subscriptions
- feature_flags
- agency_feature_entitlements