# M12 Deployment & Operations

Focus :
- CI/CD
- monitoring
- backups
- sécurité préprod
- FinOps