# M07 User Favorites & Alerts

Tables :
- favorites
- notes
- saved_searches