# M02 Agencies, Branches & Team

Tables :
- agencies
- agency_branches
- agency_memberships

Focus :
- multi-villes
- multi-agents
- rôles