# M04 Media & Storage

Tables :
- listing_media
- listing_media_history