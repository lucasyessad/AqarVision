# M06 Leads & Messaging

Tables :
- leads
- conversations
- messages