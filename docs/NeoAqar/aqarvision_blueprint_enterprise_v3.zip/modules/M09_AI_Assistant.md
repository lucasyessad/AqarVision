# M09 AI Assistant

Tables :
- ai_prompts
- ai_jobs