# M01 Auth & Identity

Tables :
- users
- mobile_devices
- push_tokens

Focus :
- SSR auth web
- PKCE mobile
- rôles