# M00 Foundations

Objectifs :
- monorepo
- i18n 4 langues
- conventions
- observabilité
- design system
- feature flags