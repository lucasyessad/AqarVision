# M11 Analytics & Events

Tables :
- listing_views
- domain_events
- audit_logs