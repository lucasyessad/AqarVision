# M03 Listings Core

Tables :
- listings
- listing_translations
- listing_documents
- listing_price_versions
- listing_status_versions
- listing_revisions

Focus :
- publication
- 4 langues
- historisation hybride