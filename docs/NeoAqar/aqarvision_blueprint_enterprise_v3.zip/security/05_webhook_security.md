# Webhook Security

- vérification signature Stripe
- body brut obligatoire
- idempotence
- journalisation des erreurs et tentatives