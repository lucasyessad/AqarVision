# Incident Response

Étapes :
1. détection
2. confinement
3. rotation secrets
4. correction
5. communication
6. post-mortem