# AI Security

- prompts versionnés
- pas de contexte cross-tenant
- validation structurée des sorties
- logs de consommation
- revue humaine possible