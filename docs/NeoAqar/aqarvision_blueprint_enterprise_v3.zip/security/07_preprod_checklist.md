# Preprod Security Checklist

- RLS activée partout
- aucun bucket sensible public
- CSP active
- logs d'audit activés
- secrets en variables d'environnement
- monitoring erreurs branché