# Storage Security

- buckets privés par défaut
- documents sensibles jamais publics
- fichiers servis via signed URLs
- contrôle MIME / taille
- suppression et rétention contrôlées