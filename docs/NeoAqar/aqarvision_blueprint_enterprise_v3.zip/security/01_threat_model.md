# Threat Model

Menaces principales :
- escalade inter-agence
- scraping annonces
- uploads malveillants
- webhooks forgés
- prompt injection
- fuite de données sensibles
- brute force auth