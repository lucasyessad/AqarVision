# Business Continuity

- backups
- RTO / RPO
- procédures de restauration
- stratégie continuité service