# Data Governance

- ownership des données
- dictionnaire de données
- source de vérité SQL centralisée
- gouvernance des événements métier