# Data Retention

À définir :
- durée de conservation leads
- durée de conservation logs
- archivage annonces expirées
- suppression compte utilisateur