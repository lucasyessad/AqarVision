
# AqarVision – Master Blueprint

## Vision

AqarVision vise à moderniser le marché immobilier algérien en créant :
- un SaaS pour agences
- une marketplace nationale
- une infrastructure data immobilière.

## Objectifs

Court terme :
- mini sites agences
- publication d'annonces
- recherche immobilière

Moyen terme :
- CRM immobilier
- leads
- automatisation IA

Long terme :
- indice immobilier national
- data analytics immobilier
- API data pour investisseurs

## Architecture

Stack :
- Next.js
- Supabase
- PostgreSQL + PostGIS
- Expo Mobile

Architecture :
Monorepo structuré avec :
- apps
- packages
- infrastructure
- database

## Modules principaux

M00 – Foundations  
M01 – Auth & Identity  
M02 – Agencies & Teams  
M03 – Listings Core  
M04 – Media Storage  
M05 – Marketplace Search  
M06 – Leads & Messaging  
M07 – Favorites & Alerts  
M08 – Billing  
M09 – AI Assistant  
M10 – Moderation  
M11 – Analytics  
M12 – CI/CD

Chaque module suit le template :
ROLE / CONTEXT / TASK / OUTPUT / CONSTRAINTS / SUCCESS / USAGE.
