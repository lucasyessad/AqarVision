
# Module M00 – Foundations

## [RÔLE]
Architecte SaaS + ingénieur fullstack spécialisé Next.js et Supabase.

## [CONTEXTE]
Ce module initialise l’architecture complète du projet :
- monorepo
- base Next.js
- configuration Supabase
- conventions du projet.

## [TÂCHE]
Créer les fondations techniques du projet :
- structure monorepo
- configuration Next.js
- configuration Supabase
- configuration TypeScript
- configuration Tailwind.

## [EXEMPLE OUTPUT]

Structure projet :

apps/
  web/
  mobile/

packages/
  ui/
  database/
  config/

## [CONTRAINTES]

- architecture monorepo obligatoire
- TypeScript strict
- composants réutilisables
- configuration i18n dès le départ

## [CRITÈRES DE SUCCÈS]

Le module est réussi si :
- le projet compile
- Supabase est connecté
- les packages partagés fonctionnent

## [UTILISATION]

Ce module est exécuté avant tous les autres.
Tous les modules suivants dépendent de ces fondations.
