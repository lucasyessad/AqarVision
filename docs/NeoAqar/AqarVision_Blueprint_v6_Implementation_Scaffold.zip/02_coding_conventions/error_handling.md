# Error Handling Convention

## Règles
- erreurs métier explicites
- erreurs sécurité non bavardes
- erreurs validation structurées
- jamais masquer silencieusement une erreur critique

## Retour recommandé
- code
- message utilisateur
- détails internes loggés séparément
