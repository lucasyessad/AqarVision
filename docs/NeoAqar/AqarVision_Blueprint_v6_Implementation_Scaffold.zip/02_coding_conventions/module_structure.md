# Module Structure Convention

Chaque feature peut suivre la structure :

feature-name/
  components/
  hooks/
  actions/
  services/
  schemas/
  types/
  utils/

## Règle
- `components/` = UI
- `actions/` = orchestration côté app
- `services/` = logique de coordination
- `schemas/` = validations
- `types/` = contrats typés
