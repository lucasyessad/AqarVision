# File Naming Conventions

## TypeScript
- kebab-case pour les fichiers utilitaires
- PascalCase pour composants React si nécessaire selon standard équipe
- suffixes explicites :
  - *.service.ts
  - *.schema.ts
  - *.types.ts
  - *.mapper.ts
  - *.policy.ts
  - *.action.ts

## SQL
- XX_domain_name.sql
- garder l’ordre d’exécution clair

## Markdown docs
- noms explicites par domaine
