# Logging Convention

## Ne pas logger
- secrets
- tokens
- données sensibles brutes

## Logger
- contexte d’action
- ids techniques
- agency_id si pertinent
- type d’événement
- résultat success/failure
