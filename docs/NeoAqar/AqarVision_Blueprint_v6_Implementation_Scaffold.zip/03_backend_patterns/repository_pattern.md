# Repository Pattern (light)

Utiliser un repository léger seulement si nécessaire pour :
- centraliser les accès listing
- centraliser les accès agency
- centraliser les accès conversation

Ne pas sur-abstraire prématurément.
