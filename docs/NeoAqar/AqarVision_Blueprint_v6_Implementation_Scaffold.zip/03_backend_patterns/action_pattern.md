# Action Pattern

## Server Action / handler type
1. validate input
2. resolve current actor
3. call domain service
4. return sanitized output
5. trigger revalidation if needed

## Interdits
- appeler la DB directement depuis la vue
- réécrire la logique métier déjà présente dans un service
