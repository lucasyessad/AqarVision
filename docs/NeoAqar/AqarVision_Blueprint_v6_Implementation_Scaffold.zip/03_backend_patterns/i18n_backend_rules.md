# Backend i18n Rules

## Règles
- locale toujours explicite dans les lectures localisées
- fallback contrôlé : locale demandée -> fr -> en
- ne jamais supposer une langue unique

## Traductions
Les contenus textuels métier passent par `listing_translations`.
