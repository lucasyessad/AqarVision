# Service Layer Pattern

## Objectif
Séparer clairement :
- orchestration applicative
- accès data
- logique métier

## Exemple
listing.service.ts
- create listing
- publish listing
- archive listing
- apply history logic
- emit domain events

## Règle
La logique métier ne vit ni dans les composants, ni dispersée dans les actions UI.
