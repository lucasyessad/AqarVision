# AqarVision Blueprint v6 — Implementation Scaffold Spec

Ce v6 sert de pont entre :
- le blueprint produit / architecture
- le design data / sécurité
- l'implémentation concrète par une équipe ou par Claude Code

## Objectif
Définir une **structure d’implémentation prescriptive** :
- arborescence exacte du monorepo
- conventions de fichiers
- conventions backend
- conventions frontend
- conventions mobile
- conventions DTO / Zod / services
- prompts d’exécution Claude module par module

## Portée
- AqarVision = écosystème
- AqarPro = CRM agences
- AqarSearch = marketplace
