# Comment utiliser le v6

## Si tu implémentes toi-même
1. Lire `01_repo_structure/monorepo_scaffold.md`
2. Lire `02_coding_conventions/`
3. Lire les patterns concernés (backend/frontend/mobile)
4. Lire les prompts Claude

## Si tu travailles avec Claude Code
1. Charger `00_CLAUDE_START_PROMPT.md`
2. Charger le module cible
3. Charger les fichiers data / policies associés
4. Exécuter selon les prompts du dossier `07_claude_execution_prompts`

## Si tu onboardes une équipe
Le v6 sert de guide d’implémentation unifié.
