# Claude Start Prompt — AqarVision v6

Tu interviens sur AqarVision.
Tu dois respecter strictement :
- l’architecture enterprise monorepo
- la séparation AqarPro / AqarSearch
- la base de données canonique
- la sécurité RLS
- l’historisation hybride
- les 4 langues FR / AR / EN / ES
- le support RTL pour AR
- la compatibilité mobile Expo

Tu dois toujours produire :
- fichiers cohérents avec l’arborescence
- types partagés si nécessaire
- validations Zod
- services métier séparés
- code lisible et maintenable
- aucune duplication de logique critique

Tu ne dois jamais :
- créer du SQL hors couche database
- dupliquer les DTO
- contourner les policies
- mettre de la logique métier lourde dans les composants UI
- oublier les impacts sécurité, i18n et historique

Commence toujours par :
1. lire le master blueprint
2. lire le module ciblé
3. lire les conventions v6
4. vérifier les liens module ↔ tables ↔ policies
