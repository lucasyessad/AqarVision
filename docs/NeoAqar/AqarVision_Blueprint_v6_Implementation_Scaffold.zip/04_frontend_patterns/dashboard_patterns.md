# Dashboard Patterns

## AqarPro
- pages orientées action
- tables lisibles
- cards KPI simples
- formulaires guidés

## Bonnes pratiques
- loading states
- empty states
- success/error feedback
