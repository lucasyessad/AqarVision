# Web Component Conventions

## Règles
- composants petits et lisibles
- props typées
- aucune logique métier lourde
- accessibilité de base respectée

## Découpage
- page component
- section component
- primitive component
