# Search UI Patterns

## AqarSearch
- barre de recherche claire
- filtres persistants
- résultats + carte
- cards homogènes
- page détail structurée

## États
- initial
- loading
- no results
- error
- partial results
