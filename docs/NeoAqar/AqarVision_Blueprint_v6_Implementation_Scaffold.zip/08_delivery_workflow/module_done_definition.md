# Definition of Done — Module

Un module est terminé si :
- son périmètre fonctionnel est livré
- ses contrats sont respectés
- sa sécurité est explicitement couverte
- les validations existent
- les tests minimaux existent
- la documentation est mise à jour
