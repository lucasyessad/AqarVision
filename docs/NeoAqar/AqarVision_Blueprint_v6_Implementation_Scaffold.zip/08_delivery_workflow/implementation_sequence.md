# Implementation Sequence

## Séquence recommandée
1. Foundations
2. Auth
3. Agencies
4. Listings
5. Media
6. Search
7. Leads / Messaging
8. Favorites / Alerts
9. Billing
10. AI
11. Moderation
12. Analytics
13. CI/CD
