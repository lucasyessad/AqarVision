# Pull Request Definition Checklist

- périmètre clair
- fichiers au bon endroit
- validations présentes
- tests adaptés
- impact sécurité vérifié
- impact i18n vérifié
- impact mobile vérifié
- impact historique vérifié si données listings
