# Prompt Claude — M09 AI Assistant

Objectif :
Implémenter l’assistant IA.

À produire :
- génération description
- traduction FR->AR/EN/ES
- journalisation coût
- contrôle sécurité

Contraintes :
- aucune fuite cross-tenant
- output structuré
- activation feature flag
