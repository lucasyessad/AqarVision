# Prompt Claude — M00 Foundations

Objectif :
Mettre en place les fondations du monorepo AqarVision.

À produire :
- structure `apps/` et `packages/`
- conventions imports
- setup i18n 4 langues
- conventions UI web/mobile
- base config partagée

Contraintes :
- respecter le v6
- aucune logique métier hors packages/domain
