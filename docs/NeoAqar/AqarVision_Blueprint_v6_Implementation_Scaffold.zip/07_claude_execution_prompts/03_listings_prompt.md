# Prompt Claude — M03 Listings Core

Objectif :
Implémenter le cœur des annonces.

À produire :
- CRUD listing
- traductions 4 langues
- publication
- déclenchement historisation hybride
- intégration AqarPro + AqarSearch

Contraintes :
- respecter schéma canonique
- respecter policies
- préserver compatibilité mobile
