# Prompt Claude — M05 Search Marketplace

Objectif :
Implémenter la recherche publique AqarSearch.

À produire :
- search UI
- filtres
- map integration
- get listing by slug
- pages SEO

Contraintes :
- SEO multilingue
- performance
- lecture publique uniquement des annonces publiées
