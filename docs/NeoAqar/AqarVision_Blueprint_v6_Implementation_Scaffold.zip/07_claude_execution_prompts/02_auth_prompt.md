# Prompt Claude — M01 Auth Identity

Objectif :
Implémenter l’auth web/mobile et les profils.

À produire :
- flows signup/signin/signout
- profil utilisateur
- locale préférée
- support mobile PKCE
- séparation rôles globaux / rôles agence

Contraintes :
- sécurité stricte
- pas de duplication de logique auth
