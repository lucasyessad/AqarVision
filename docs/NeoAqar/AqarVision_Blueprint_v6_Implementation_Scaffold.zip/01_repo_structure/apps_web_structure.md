# apps/web structure

## app/
- [locale]/
- (marketing)/
- (auth)/
- (dashboard)/
- api/

## features/
Modules UI et orchestration côté web, jamais source de vérité data.

## lib/
- supabase clients
- i18n helpers
- auth helpers
- seo helpers

## Convention
Le web consomme :
- packages/domain
- packages/api-client
- packages/ui-web
