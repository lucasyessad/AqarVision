# apps/mobile structure

## app/
- routes / screens

## features/
- écrans par domaine
- orchestration mobile

## lib/
- auth mobile
- secure storage
- i18n
- notifications

## Convention
Le mobile consomme :
- packages/domain
- packages/api-client
- packages/ui-mobile
