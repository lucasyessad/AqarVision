# packages structure

## packages/domain
Logique métier pure :
- services
- policies métier
- types métier
- mapping

## packages/database
SQL, migrations, dictionnaire, RLS, triggers

## packages/ui-web
Composants web partagés

## packages/ui-mobile
Composants mobile partagés

## packages/api-client
Wrappers d’accès à Supabase / APIs

## packages/security
Guards, helpers sécurité, conventions

## packages/feature-flags
Registre des flags et résolution

## packages/analytics
Events, métriques, tracking helpers
