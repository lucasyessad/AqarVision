# Monorepo Scaffold

## Structure cible
aqarvision/
  apps/
    web/
      app/
      components/
      features/
      lib/
      hooks/
      styles/
    mobile/
      app/
      components/
      features/
      lib/
      hooks/
  packages/
    domain/
    database/
    ui-web/
    ui-mobile/
    api-client/
    analytics/
    security/
    feature-flags/
    config/

## Principe
- `apps/` = points d’entrée
- `packages/` = logique réutilisable ou transversale
