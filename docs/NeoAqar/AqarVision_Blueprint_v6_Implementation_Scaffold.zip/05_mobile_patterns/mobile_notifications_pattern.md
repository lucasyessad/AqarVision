# Mobile Notifications Pattern

## Flux
- event métier
- résolution des destinataires
- lookup push token
- envoi notification
- journalisation

## Cas
- nouveau lead
- nouveau message
- baisse de prix d’un favori
