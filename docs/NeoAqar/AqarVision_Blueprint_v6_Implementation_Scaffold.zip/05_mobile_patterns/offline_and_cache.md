# Offline & Cache Rules

## MVP
- cache léger des dernières listes
- favoris persistés localement
- reprise simple

## Plus tard
- queue offline pour certaines actions
- sync optimiste mieux gérée
