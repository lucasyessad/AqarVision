# Mobile Screen Conventions

## Règles
- écrans simples
- interactions tactiles évidentes
- navigation cohérente
- composants optimisés petits écrans
- support RTL complet
