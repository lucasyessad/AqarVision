# DTO Conventions

## Input DTO
Toujours valider via Zod ou équivalent.

## Output DTO
Retourner des formes stables et minimales.

## Règle
Ne pas exposer les colonnes internes inutiles au client.
