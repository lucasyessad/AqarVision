# Type Sharing Strategy

## Packages concernés
- packages/domain
- packages/api-client
- apps/web
- apps/mobile

## Règle
Les types métier partagés vivent hors des apps.
