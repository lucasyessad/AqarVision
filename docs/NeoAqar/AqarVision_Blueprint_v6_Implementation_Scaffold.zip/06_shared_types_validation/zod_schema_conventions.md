# Zod Schema Conventions

## Exemple de séparation
- listing-create.schema.ts
- listing-publish.schema.ts
- search-filters.schema.ts

## Règles
- schémas réutilisables
- messages clairs
- validations alignées au modèle data
