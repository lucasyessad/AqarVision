# Comment utiliser le v5

## Pour un CTO / architecte
Lire :
1. mapping module ↔ data
2. API contracts
3. policies RLS
4. testing strategy

## Pour Claude Code
Lire :
1. module concerné (v2)
2. schéma canonique (v4)
3. API contract (v5)
4. server actions (v5)
5. tests associés (v5)

## Pour un backend engineer
Commencer par :
- `01_mapping/module_to_tables.md`
- `02_api_contracts/`
- `04_database/policies/`

## Pour un security reviewer
Commencer par :
- `04_database/policies/`
- `06_security/`
- `05_testing/security_test_matrix.md`
