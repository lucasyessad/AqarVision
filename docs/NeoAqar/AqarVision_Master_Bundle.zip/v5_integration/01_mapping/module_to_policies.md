# Mapping module ↔ policies RLS

## M01
- profiles_select_self
- profiles_update_self

## M02
- agencies_select_member
- agency_branches_select_member
- agency_memberships_select_member
- agency_invites_admin_only

## M03
- listings_select_public
- listings_select_member
- listings_modify_member
- listing_translations_public_if_listing_published
- listing_documents_member_only

## M04
- listing_media_public_if_listing_published
- listing_media_modify_member

## M05
- listings_select_public
- listing_translations_public_if_listing_published
- favorites_self
- saved_searches_self

## M06
- leads_agency_member
- leads_sender_self
- conversations_participant_only
- messages_participant_only

## M07
- favorites_self
- notes_self
- saved_searches_self
- view_history_self

## M08
- subscriptions_admin_only
- entitlements_admin_only

## M09
- ai_jobs_agency_member
- ai_jobs_admin_write

## M10
- moderation_super_admin_only
- audit_logs_super_admin_only

## M11
- domain_events_super_admin_or_system
- analytics_admin_only
