# Mapping module ↔ tables principales

## M00 Foundations
- users
- profiles
- mobile_devices
- push_tokens

## M01 Auth & Identity
- users
- profiles
- mobile_devices
- push_tokens

## M02 Agencies & Branches
- agencies
- agency_branches
- agency_memberships
- agency_invites

## M03 Listings Core
- listings
- listing_translations
- listing_documents
- listing_price_versions
- listing_status_versions
- listing_revisions

## M04 Media Storage
- listing_media
- listing_media_history

## M05 Search Marketplace
- listings
- listing_translations
- listing_media
- favorites
- saved_searches
- view_history

## M06 Leads Messaging
- leads
- conversations
- messages

## M07 Favorites Alerts
- favorites
- notes
- saved_searches
- view_history

## M08 Billing
- plans
- subscriptions
- agency_feature_entitlements

## M09 AI
- ai_prompts
- ai_jobs

## M10 Moderation
- listing_moderation_history
- audit_logs

## M11 Analytics
- domain_events
- listing_views
- agency_stats_daily
- audit_logs

## M12 CI/CD
- aucune table métier directe, mais dépend de toutes les précédentes
