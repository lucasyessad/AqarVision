# Module → API → Policy mapping

## M03 Listings
APIs:
- createListing
- upsertListingTranslation
- publishListing

Policies:
- listings_select_member
- listings_modify_member
- listing_translations_modify_member

## M06 Leads
APIs:
- createLead
- sendMessage

Policies:
- leads_agency_member
- conversations_participant_only
- messages_participant_only

## M09 AI
APIs:
- generateListingDescription
- translateListing

Policies:
- ai_jobs_agency_member
