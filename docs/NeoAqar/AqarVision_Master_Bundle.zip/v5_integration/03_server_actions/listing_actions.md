# Listing Server Actions (pseudo)

- create_listing_action
- update_listing_action
- upsert_translation_action
- publish_listing_action
- archive_listing_action

Règles :
- revalider les droits via RLS + contexte serveur
- écrire dans listing_revisions si modification majeure
- déclencher history sur prix / statut
- pousser domain_events
