# AI Server Actions (pseudo)

- generate_listing_ai_action
- translate_listing_ai_action

Règles :
- contexte minimal
- pas de fuite cross-tenant
- journaliser coût et output
- valider structure de sortie
