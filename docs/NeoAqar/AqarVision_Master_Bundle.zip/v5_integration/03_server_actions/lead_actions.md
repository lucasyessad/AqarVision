# Lead Server Actions (pseudo)

- create_lead_action
- create_conversation_action
- send_message_action
- mark_conversation_read_action

Règles :
- conversation privée
- audit si action sensible
- push notifications possibles
