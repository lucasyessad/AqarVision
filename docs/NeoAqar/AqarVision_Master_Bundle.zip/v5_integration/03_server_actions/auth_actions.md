# Auth Server Actions (pseudo)

- sign_up_action
- sign_in_action
- sign_out_action
- update_profile_action

Règles :
- valider input
- utiliser Supabase Auth
- créer / mettre à jour profile
- journaliser actions sensibles
