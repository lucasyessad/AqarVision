# Billing Server Actions (pseudo)

- start_checkout_action
- open_customer_portal_action
- apply_feature_entitlements_action

Règles :
- admin agence uniquement
- webhook externe toujours vérifié
