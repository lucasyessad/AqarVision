# Media Server Actions (pseudo)

- create_signed_upload_url_action
- finalize_media_upload_action
- reorder_media_action
- delete_media_action

Règles :
- bucket privé
- path normalisé
- media_history mis à jour
