# Control Mapping

## Access Control
- RLS
- role separation
- agency membership helpers

## Data Protection
- private buckets
- signed URLs
- audit logs

## Billing Security
- verified webhooks
- limited admin scope

## AI Security
- minimal context
- structured outputs
- logging
