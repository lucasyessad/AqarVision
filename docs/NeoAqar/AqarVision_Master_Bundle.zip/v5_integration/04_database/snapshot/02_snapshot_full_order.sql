-- Canonical execution order

\i ../schema/00_extensions.sql
\i ../schema/01_enums.sql
\i ../schema/10_identities.sql
\i ../schema/20_organizations.sql
\i ../schema/30_listings.sql
\i ../schema/40_marketplace.sql
\i ../schema/50_billing_ai_analytics.sql

\i ../history/02_listing_price_versions.sql
\i ../history/03_listing_status_versions.sql
\i ../history/04_listing_revisions.sql
\i ../history/05_listing_event_history.sql

\i ../indexes/01_core_indexes.sql
\i ../indexes/02_history_indexes.sql

\i ../functions/01_security_helpers.sql
\i ../functions/02_updated_at_helper.sql

\i ../rls/10_profiles.sql
\i ../rls/20_agencies.sql
\i ../rls/30_listings.sql
\i ../rls/40_marketplace.sql
\i ../rls/50_billing_ai_audit.sql
