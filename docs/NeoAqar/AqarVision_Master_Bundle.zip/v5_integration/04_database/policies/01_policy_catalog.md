# Policy Catalog

## Profiles
- profiles_select_self
- profiles_update_self

## Organizations
- agencies_select_member
- agencies_admin_modify
- branches_select_member
- branches_admin_modify
- memberships_select_member
- invites_admin_only

## Listings
- listings_select_public
- listings_select_member
- listings_modify_member
- listing_translations_select_public_if_listing_published
- listing_translations_modify_member
- listing_media_select_public_if_listing_published
- listing_media_modify_member
- listing_documents_member_only

## Marketplace
- favorites_self
- notes_self
- saved_searches_self
- view_history_self
- leads_agency_member
- leads_sender_self
- conversations_participant_only
- messages_participant_only

## Billing / AI / Audit
- subscriptions_admin_only
- entitlements_admin_only
- ai_jobs_agency_member
- audit_logs_super_admin_only
- domain_events_system_only
