-- agencies_select_member
-- create policy agencies_select_member on agencies
-- for select using (is_agency_member(auth.uid(), id));

-- agencies_admin_modify
-- create policy agencies_admin_modify on agencies
-- for update using (is_agency_admin(auth.uid(), id))
-- with check (is_agency_admin(auth.uid(), id));
