-- favorites_self
-- create policy favorites_self on favorites
-- for all using (user_id = auth.uid()) with check (user_id = auth.uid());

-- notes_self
-- create policy notes_self on notes
-- for all using (user_id = auth.uid()) with check (user_id = auth.uid());

-- leads_agency_member
-- create policy leads_agency_member on leads
-- for select using (is_agency_member(auth.uid(), agency_id));
