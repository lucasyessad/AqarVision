-- profiles_select_self
-- create policy profiles_select_self on profiles
-- for select using (user_id = auth.uid());

-- profiles_update_self
-- create policy profiles_update_self on profiles
-- for update using (user_id = auth.uid())
-- with check (user_id = auth.uid());
