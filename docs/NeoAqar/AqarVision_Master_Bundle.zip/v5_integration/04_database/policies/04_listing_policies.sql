-- listings_select_public
-- create policy listings_select_public on listings
-- for select using (current_status = 'published');

-- listings_select_member
-- create policy listings_select_member on listings
-- for select using (is_agency_member(auth.uid(), agency_id));

-- listings_modify_member
-- create policy listings_modify_member on listings
-- for update using (is_agency_member(auth.uid(), agency_id))
-- with check (is_agency_member(auth.uid(), agency_id));
