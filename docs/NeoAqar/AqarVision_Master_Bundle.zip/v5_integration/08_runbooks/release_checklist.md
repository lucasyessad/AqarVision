# Release Checklist

- migrations reviewed
- RLS reviewed
- SQL tests green
- security tests green
- i18n checks done (FR/AR/EN/ES)
- SEO metadata checked
- snapshot updated
