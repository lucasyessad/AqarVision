# DB Change Runbook

1. update schema file
2. update indexes if needed
3. update RLS if access model changes
4. update snapshot order
5. update data dictionary
6. run SQL tests
7. run security tests
