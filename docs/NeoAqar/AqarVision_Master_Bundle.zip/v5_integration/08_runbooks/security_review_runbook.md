# Security Review Runbook

Before shipping any sensitive change:
- review affected tables
- review affected policies
- review audit impact
- review domain_events side effects
- review storage/webhook implications
