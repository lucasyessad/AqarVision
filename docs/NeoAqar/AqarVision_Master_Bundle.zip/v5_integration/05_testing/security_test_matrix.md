# Security Test Matrix

## RLS
- user A cannot read user B notes
- agency A cannot read agency B listings draft
- public can only read published listings

## Billing
- non-admin agency member cannot read subscription details if restricted

## AI
- agency A cannot access agency B ai_jobs

## Storage
- invalid signed upload rejected
