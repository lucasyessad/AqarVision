# Testing Strategy

Ce dossier définit les tests attendus autour de :
- SQL structure
- triggers
- policies RLS
- security flows
- server actions
