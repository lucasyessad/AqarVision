# SQL Test Matrix

## Core
- create user/profile
- create agency
- create branch
- create listing
- create translation

## History
- update price => version old closed + new current created
- update status => same logic
- create revision on major update

## Constraints
- unique translation locale per listing
- unique current row in SCD2 tables
- no overlap on valid_during
