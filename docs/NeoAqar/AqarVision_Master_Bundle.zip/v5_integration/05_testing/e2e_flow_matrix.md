# E2E Flow Matrix

## Agency flow
signup -> create agency -> create listing -> add translations -> upload media -> publish -> receive lead

## End user flow
signup -> search -> favorite -> note -> contact agency -> receive reply

## Billing flow
admin starts checkout -> webhook sync -> entitlements applied

## AI flow
agent requests AI description -> translations produced -> review -> publish
