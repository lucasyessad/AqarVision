# Auth Contracts

## signUp
Input:
- email
- password
- preferred_locale

Output:
- user_id
- profile_created
- next_step

## signIn
Input:
- email
- password

Output:
- session
- role
- preferred_locale

## updateProfile
Input:
- full_name
- avatar_url
- phone
- preferred_locale

Output:
- profile_snapshot
