# Billing Contracts

## startCheckout
Input:
- agency_id
- plan_code

Output:
- checkout_url

## syncSubscriptionFromWebhook
Input:
- verified webhook payload

Output:
- subscription_snapshot
