# AI Contracts

## generateListingDescription
Input:
- listing_id
- source_locale=fr
- target_locales=[ar,en,es]

Output:
- generated_translations
- ai_job_id
- cost_estimated

## translateListing
Input:
- listing_id
- source_locale
- target_locale

Output:
- translated_fields
