# Listing Contracts

## createListing
Input:
- agency_id
- branch_id
- listing_type
- property_type
- current_price
- wilaya_code
- commune_id
- details

Output:
- listing_id
- current_status=draft

## upsertListingTranslation
Input:
- listing_id
- locale
- title
- description
- slug

Output:
- translation_id

## publishListing
Input:
- listing_id

Preconditions:
- 4 translations present
- minimum data complete
- access rights valid

Output:
- published_at
- new_status=published
