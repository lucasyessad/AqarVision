# Agency Contracts

## createAgency
Input:
- name
- slug
- description
- phone
- email

Output:
- agency_id
- owner_membership_id

## createBranch
Input:
- agency_id
- name
- wilaya_code
- commune_id
- address_text
- location

Output:
- branch_id

## inviteMember
Input:
- agency_id
- email
- role

Output:
- invite_id
- token_generated
