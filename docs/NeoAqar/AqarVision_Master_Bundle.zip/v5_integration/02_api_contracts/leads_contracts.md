# Leads & Messaging Contracts

## createLead
Input:
- listing_id
- message
- source

Output:
- lead_id
- conversation_id

## sendMessage
Input:
- conversation_id
- body

Output:
- message_id
- created_at

## listConversations
Input:
- current_user_context

Output:
- conversation summaries
