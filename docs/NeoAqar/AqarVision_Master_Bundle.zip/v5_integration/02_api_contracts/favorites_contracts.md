# Favorites Contracts

## toggleFavorite
Input:
- listing_id

Output:
- is_favorite

## saveSearch
Input:
- name
- filters

Output:
- saved_search_id

## saveNote
Input:
- listing_id
- body

Output:
- note_id
