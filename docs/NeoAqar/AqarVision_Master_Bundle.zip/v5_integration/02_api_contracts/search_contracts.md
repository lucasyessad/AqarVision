# Search Contracts

## searchListings
Input:
- locale
- listing_type
- property_type
- wilaya_code
- commune_id
- price_min
- price_max
- rooms_min
- map_bounds
- page
- page_size

Output:
- listings[]
- total_count
- map_points[]

## getListingBySlug
Input:
- locale
- slug

Output:
- listing detail localized
- media
- agency summary
