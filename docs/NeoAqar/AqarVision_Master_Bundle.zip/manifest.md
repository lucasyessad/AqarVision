# Manifest — AqarVision Master Bundle

## Sources intégrées
- v2_product_architecture: dir
- v3_database_security: dir
- v4_sql_canonical: dir
- v5_integration: dir
- v6_implementation_scaffold: dir
- v7_design_ui: dir

## Structure
- README_MASTER_BUNDLE.md
- MASTER_EXECUTION_ORDER.md
- v2_product_architecture/
- v3_database_security/
- v4_sql_canonical/
- v5_integration/
- v6_implementation_scaffold/
- v7_design_ui/
