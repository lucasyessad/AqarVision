# Master Execution Order

## Étape 1 — Lire la vision
- v2_product_architecture/01_product_vision/
- v2_product_architecture/03_architecture/

## Étape 2 — Valider la couche data et sécurité
- v3_database_security/
- v4_sql_canonical/

## Étape 3 — Préparer l’implémentation
- v5_integration/
- v6_implementation_scaffold/

## Étape 4 — Finaliser l’UX / design / handoff
- v7_design_ui/

## Étape 5 — Lancer le développement
Priorité :
1. M00_Foundations
2. M01_Auth_Identity
3. M02_Agencies_Branches
4. M03_Listings_Core
5. M04_Media_Storage
6. M05_Search_Marketplace
7. M06_Leads_Messaging
8. M07_Favorites_Alerts
9. M08_Billing_Stripe
10. M09_AI_Assistant
11. M10_Moderation_Admin
12. M11_Analytics_Events
13. M12_CICD_Deployment
