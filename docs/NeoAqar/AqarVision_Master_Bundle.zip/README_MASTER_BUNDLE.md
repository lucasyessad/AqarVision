# AqarVision Master Bundle

Ce bundle regroupe tous les packs produits pour AqarVision :

- **v2** : vision produit, architecture, modules
- **v3** : base de données et sécurité renforcées
- **v4** : SQL canonique, RLS, historique
- **v5** : intégration modules ↔ APIs ↔ policies ↔ tests
- **v6** : conventions d’implémentation et prompts Claude
- **v7** : design system, UX, UI, RTL, handoff

## Ordre de lecture recommandé

1. `v2_product_architecture/00_MASTER_BLUEPRINT_AqarVision_v2.md`
2. `v3_database_security/00_master/00_DECISIONS_FINALES.md`
3. `v4_sql_canonical/00_master/00_SCOPE_AND_DECISIONS.md`
4. `v5_integration/00_master/00_HOW_TO_USE_V5.md`
5. `v6_implementation_scaffold/00_master/00_CLAUDE_START_PROMPT.md`
6. `v7_design_ui/00_master/README.md`

## Ordre conseillé pour lancer le projet

1. Foundations / Auth / Agencies
2. Listings / Media / Search
3. Leads / Favorites
4. Billing / AI / Moderation
5. Analytics / CI-CD
6. Design polish / mobile optimisation

## Objectif du bundle

Fournir un dossier unique, cohérent et exploitable pour :
- fondateur / CTO
- équipe produit
- backend / frontend / mobile
- sécurité
- Claude Code

## Nomenclature produit

- **AqarVision** = écosystème global
- **AqarPro** = CRM agences / promoteurs
- **AqarSearch** = marketplace publique
