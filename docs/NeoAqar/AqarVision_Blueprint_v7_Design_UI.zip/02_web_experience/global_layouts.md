# Web Global Layouts

## Layout marketplace
- header simple
- search bar visible
- contenu centré
- filtres sticky
- carte optionnelle
- CTA contact visibles

## Layout CRM
- sidebar
- topbar légère
- contenu modulaire
- actions rapides
- breadcrumb sobre

## Layout marketing
- hero fort
- bénéfices clairs
- démonstration produit
- CTA essai / contact
