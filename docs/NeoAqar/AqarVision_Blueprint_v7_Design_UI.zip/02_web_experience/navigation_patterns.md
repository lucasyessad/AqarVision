# Navigation Patterns

## AqarSearch
- navigation légère
- orientation par recherche et découverte
- raccourcis : Acheter / Louer / Vacances / Agences

## AqarPro
- navigation par modules :
  - dashboard
  - annonces
  - leads
  - équipe
  - analytics
  - paramètres

## Règles
- jamais de profondeur excessive
- navigation compréhensible en 1 coup d’œil
