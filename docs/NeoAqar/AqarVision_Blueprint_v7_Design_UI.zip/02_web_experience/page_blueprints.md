# Page Blueprints

## Page Search
Sections :
- barre de recherche
- filtres
- résultat count
- grid résultats
- carte
- pagination ou infinite scroll

## Page Listing Detail
Sections :
- galerie médias
- titre / prix / localisation
- caractéristiques clés
- description
- documents visibles si autorisés
- agence
- CTA contact
- biens similaires

## Page Agency
Sections :
- header agence
- branding
- coordonnées
- biens actifs
- présentation
- CTA contact

## Page AqarPro Dashboard
Sections :
- KPI
- annonces récentes
- leads récents
- actions rapides
- état de l’abonnement
