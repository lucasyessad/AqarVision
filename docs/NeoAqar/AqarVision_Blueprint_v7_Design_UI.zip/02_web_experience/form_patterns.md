# Form Patterns

## Principes
- formulaires découpés en étapes si longs
- validation immédiate mais non agressive
- autosave si pertinent
- feedback clair

## Formulaire annonce
Étapes recommandées :
1. type + transaction
2. localisation
3. caractéristiques
4. médias
5. contenus 4 langues
6. preview + publication

## Aides UX
- placeholders utiles
- textes d’aide courts
- indicateurs de progression
