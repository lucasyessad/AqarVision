# Brand Positioning

## Ton général
AqarVision doit inspirer :
- confiance
- modernité
- rigueur
- premium discret
- intelligence produit

## Style
Pas "bling". Pas "cheap". Pas "template générique".
Positionnement :
- luxury tech
- proptech sérieuse
- marketplace nationale crédible

## Différence
AqarPro :
- plus dense
- plus opératoire
- plus dashboard

AqarSearch :
- plus émotionnel
- plus éditorial
- plus orienté découverte et conversion
