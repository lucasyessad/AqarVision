# Typography

## Principes
- hiérarchie claire
- lisibilité mobile avant tout
- support multilingue
- arabe lisible et spacieux

## Recommandations
- une fonte sans-serif moderne pour FR/EN/ES
- une fonte arabe compatible, nette, non décorative
- tailles généreuses sur les pages détail
- densité plus contrôlée côté AqarPro

## Règles
- titres courts
- paragraphes aérés
- labels explicites
- éviter la micro-typographie décorative
