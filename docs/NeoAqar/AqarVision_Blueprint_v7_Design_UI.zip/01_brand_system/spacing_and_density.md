# Spacing & Density

## AqarSearch
- plus aéré
- cartes larges
- photos valorisées
- scroll confortable

## AqarPro
- densité modérée
- dashboards lisibles
- tables compactes mais respirantes

## Règles globales
- mobile first
- espacements cohérents
- grilles simples
- éviter les écrans surchargés
