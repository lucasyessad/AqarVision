# Color System

## Palette de base
- Bleu nuit : #1a202c
- Or : #d4af37
- Blanc cassé : #f7fafc

## Usage
### Bleu nuit
- navigation
- surfaces premium
- headers
- dashboards structurants

### Or
- accents
- badges premium
- éléments de distinction
- jamais en surcharge

### Blanc cassé
- fonds principaux
- cartes
- zones de respiration

## Règles
- éviter trop de contraste agressif
- garder lisibilité forte
- ne pas faire un thème trop sombre partout côté marketplace
