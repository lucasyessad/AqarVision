# Leads CRM Patterns

## Vue liste
- lead source
- bien concerné
- statut
- dernier message
- date de création

## Vue détail
- timeline
- conversation
- infos utilisateur
- actions de qualification

## Objectif
Transformer rapidement les leads en opportunités.
