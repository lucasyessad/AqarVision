# Listing Management Patterns

## Liste d’annonces
- recherche interne
- filtres
- statut
- prix
- branche
- date de mise à jour

## Actions rapides
- éditer
- dupliquer
- archiver
- publier / dépublier
- voir preview

## Objectif
Gagner du temps quotidiennement.
