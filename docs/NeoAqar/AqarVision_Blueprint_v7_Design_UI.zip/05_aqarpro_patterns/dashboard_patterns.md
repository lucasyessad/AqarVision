# AqarPro Dashboard Patterns

## KPI prioritaires
- annonces actives
- leads nouveaux
- messages non lus
- taux de complétude
- usage IA
- état abonnement

## Règles
- dashboard orienté action
- pas seulement décoratif
- priorité aux actions suivantes
