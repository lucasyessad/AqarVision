# Trust Patterns

## Signaux de confiance
- agence vérifiée
- complétude annonce
- dernière mise à jour
- historique de prix
- réponse rapide
- documents déclarés

## Objectif
Augmenter la crédibilité sans rendre la page anxiogène.
