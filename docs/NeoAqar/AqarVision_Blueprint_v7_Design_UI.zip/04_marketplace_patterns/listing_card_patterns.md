# Listing Card Patterns

## Contenu minimal
- photo cover
- prix
- titre
- localisation
- caractéristiques clés
- badge éventuel
- CTA discret favori

## Badges possibles
- nouveau
- baisse de prix
- vérifié
- sponsorisé

## Règles
- cartes homogènes
- pas de surcharge texte
- lecture rapide
