# Listing Detail Patterns

## Ordre recommandé
1. médias
2. prix
3. titre
4. localisation
5. caractéristiques
6. description
7. documents / infos juridiques si affichables
8. agence
9. contact
10. biens similaires

## Conversion
Le contact doit toujours rester visible et simple.
