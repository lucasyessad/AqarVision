# Search Experience

## Objectif
Aider à trouver vite un bien sans effort.

## Principes
- recherche rapide
- filtres lisibles
- pas de surcharge
- comparaison intuitive
- carte utile mais non bloquante

## Priorités UX
- pertinence
- vitesse perçue
- cohérence mobile/web
