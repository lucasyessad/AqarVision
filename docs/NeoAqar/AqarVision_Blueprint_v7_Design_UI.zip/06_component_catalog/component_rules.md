# Component Rules

## Règles globales
- un composant = une responsabilité claire
- props typées
- variantes explicites
- accessibilité de base
- prise en compte RTL

## Interdits
- composants gigantesques
- logique métier enfouie dans le rendu
- styles incohérents entre web et mobile
