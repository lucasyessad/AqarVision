# Core Primitives

## Web
- Button
- Input
- Select
- Card
- Badge
- Tabs
- Dialog
- Drawer
- Table
- EmptyState
- Skeleton

## Mobile
- Button
- Input
- Card
- Badge
- BottomSheet
- Tabs
- ListItem
- EmptyState
- Skeleton
