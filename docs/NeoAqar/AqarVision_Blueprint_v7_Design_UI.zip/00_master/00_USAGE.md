# Comment utiliser le v7

## Pour un Product Designer
Lire :
1. brand_system
2. web_experience
3. mobile_experience
4. component_catalog

## Pour Claude Code
Lire :
1. le module métier concerné
2. les patterns UX correspondants
3. le composant du catalogue
4. les contraintes i18n/RTL

## Pour un Frontend Engineer
Lire :
1. component_catalog
2. multilingual_rtl
3. web_experience ou mobile_experience
