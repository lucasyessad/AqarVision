# AqarVision Blueprint v7 — Design & UI System

Ce pack v7 complète les v2 à v6 avec une couche dédiée :
- branding
- design system
- UX patterns
- structure des écrans
- règles UI web et mobile
- support FR / AR / EN / ES
- RTL production-ready

## Positionnement
AqarVision = écosystème
- AqarPro = CRM agences
- AqarSearch = marketplace publique

## Objectif
Créer un référentiel visuel et UX suffisamment précis pour :
- guider un designer produit
- guider Claude Code dans l’implémentation UI
- garder une cohérence premium entre web et mobile
