# Mobile Interactions

## Règles
- targets tactiles confortables
- gestes simples
- éviter les modales complexes
- feedback immédiat sur action

## Cas importants
- ajout favori
- envoi message
- publication annonce
- upload photo
