# Mobile Information Architecture

## AqarSearch mobile
Tabs / sections possibles :
- Accueil
- Recherche
- Favoris
- Messages
- Compte

## AqarPro mobile
Tabs / sections possibles :
- Dashboard
- Annonces
- Leads
- Messages
- Paramètres

## Règles
- pas trop de profondeur
- actions fréquentes accessibles en 1-2 taps
