# Mobile Screen Blueprints

## Search mobile
- champ recherche haut
- chips filtres
- résultats cards
- bouton carte

## Listing detail mobile
- galerie swipe
- prix et titre visibles immédiatement
- CTA contact sticky bas
- sections repliables

## CRM annonce mobile
- édition guidée
- upload caméra
- sauvegarde brouillon
- état publication visible
