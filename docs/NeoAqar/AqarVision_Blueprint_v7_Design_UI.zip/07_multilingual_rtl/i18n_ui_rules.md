# i18n UI Rules

## Langues
- FR
- AR
- EN
- ES

## Règles
- jamais hardcoder du texte
- labels suffisamment courts
- gérer les variations de longueur
- adapter les formats prix / dates
