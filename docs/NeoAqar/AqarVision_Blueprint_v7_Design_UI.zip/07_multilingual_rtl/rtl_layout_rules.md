# RTL Layout Rules

## Concerné
- AR uniquement

## Règles
- utiliser des propriétés logiques
- ne pas coder en dur left/right partout
- vérifier l’ordre des icônes, badges, flèches
- tester formulaires et tables en RTL

## But
Avoir un RTL naturel, pas juste “miroir approximatif”.
