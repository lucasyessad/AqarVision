# Content Density by Language

## FR / EN / ES
- contenus souvent plus compacts
- labels plus courts

## AR
- respiration plus importante
- attention aux retours ligne
- attention aux CTA trop serrés

## Règle
Le design doit absorber les différences de densité sans casser la grille.
