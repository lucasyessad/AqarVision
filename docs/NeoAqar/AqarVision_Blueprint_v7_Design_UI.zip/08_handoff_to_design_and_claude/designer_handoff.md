# Designer Handoff

## Ce qu’un designer doit produire à partir du v7
- design system
- maquettes search
- maquettes listing detail
- dashboard AqarPro
- flux création annonce
- adaptations mobile
- variantes RTL

## Priorité
1. marketplace
2. dashboard pro
3. écrans mobiles critiques
