# Frontend Delivery Checklist

- textes externalisés
- RTL vérifié
- responsive vérifié
- loading / empty / error states présents
- CTA clairs
- cohérence visuelle respectée
- accessibilité de base ok
