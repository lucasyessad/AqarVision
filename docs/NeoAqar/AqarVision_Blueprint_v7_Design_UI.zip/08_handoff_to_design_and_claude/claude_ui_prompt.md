# Claude UI Prompt

Tu implémentes l’interface AqarVision.

Contraintes :
- respecter le v7 design/UI
- respecter i18n 4 langues
- supporter RTL pour AR
- utiliser les composants du catalogue
- garder la logique métier hors des composants
- maintenir la cohérence entre AqarSearch et AqarPro

Priorité :
- lisibilité
- cohérence
- simplicité
- performance perçue
- support mobile
