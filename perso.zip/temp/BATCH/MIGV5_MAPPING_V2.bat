@echo off
setlocal EnableDelayedExpansion

REM -----------------------------------------------------------------------
REM MIG V5 - PARAM_MAPPING_V4_V5
REM -----------------------------------------------------------------------

set "RC=0"
set "HAS_ERROR=0"

REM =====================================================================
REM PARAMETRES
REM =====================================================================
set "Server=erm"
set "DataBase=dwh"

set "SOURCE_DIR=\\kenya\dsi\exploit\datalib\migv5lig\Depot"
set "REF_DIR=\\kenya\dsi\exploit\datalib\migv5lig\referentiel"
set "ARCHIVE_DIR=\\kenya\dsi\exploit\datalib\migv5lig\Archives"
set "ERREUR_DIR=\\kenya\dsi\exploit\datalib\migv5lig\Erreurs"
set "CSV_FILE=PARAM_MAPPING_V4_V5.csv"

set "SCRIPT_DIR=\\kenya\dsi\exploit\proclib\migv5lig"
set "SQL_CREATE=%SCRIPT_DIR%\mapping_0_create_all_tables.sql"
set "SQL_LOAD=%SCRIPT_DIR%\mapping_1_load_tmp.sql"
set "SQL_EXTRACT=%SCRIPT_DIR%\mapping_2_extraction_rejets.sql"
set "SQL_INTEG=%SCRIPT_DIR%\mapping_3_integrate_final.sql"

REM =====================================================================
REM HORODATAGE
REM =====================================================================
for /f "tokens=2 delims==." %%a in ('wmic os get LocalDateTime /value 2^>nul') do set "DT=%%a"
set "TS=!DT:~0,8!_!DT:~8,6!"

REM =====================================================================
REM CONTROLE REPERTOIRES
REM =====================================================================
if not exist "%ERREUR_DIR%"  mkdir "%ERREUR_DIR%"
if not exist "%ARCHIVE_DIR%" mkdir "%ARCHIVE_DIR%"
if not exist "%REF_DIR%"     mkdir "%REF_DIR%"

echo ================================================================
echo MIG V5 - PARAM_MAPPING - [!TS!]
echo ================================================================

REM =====================================================================
REM ETAPE 1 � CONTROLE DU FICHIER
REM =====================================================================
echo [ETAPE 1/5] Controle fichier source...

if not exist "%SOURCE_DIR%\%CSV_FILE%" (
    echo   KO - Fichier introuvable
    set "RC=10"
    goto FIN
)

echo   OK - Fichier trouv� : %CSV_FILE%

REM =====================================================================
REM ETAPE 2 � TABLES
REM =====================================================================
echo [ETAPE 2/5] Creation / verification tables...

sqlcmd -S %Server% -d %DataBase% -E -i "%SQL_CREATE%"
if errorlevel 1 (
    echo   KO - Erreur creation tables
    set "RC=11"
    goto FIN
)

echo   OK - Tables pretes

REM =====================================================================
REM ETAPE 3 � CHARGEMENT TMP
REM =====================================================================
echo [ETAPE 3/5] Chargement TMP...

sqlcmd -S %Server% -d %DataBase% -E ^
    -v CSVFILE="%SOURCE_DIR%\%CSV_FILE%" ^
    -i "%SQL_LOAD%" -h -1 -W > "%ERREUR_DIR%\LOAD_%TS%.log" 2>&1

if errorlevel 1 (
    echo   KO - Erreur chargement TMP
    set "HAS_ERROR=1"
    goto FIN
)

echo   OK - TMP charg�e

REM =====================================================================
REM ETAPE 4 � EXTRACTION DES REJETS
REM =====================================================================
echo [ETAPE 4/5] Extraction des rejets (NULL + doublons)...

set "TMP_REJET=%ERREUR_DIR%\MAPPING_REJETS_%TS%.csv"

sqlcmd -S %Server% -d %DataBase% -E ^
    -i "%SQL_EXTRACT%" ^
    -s ";" -W -h -1 ^
    -o "%TMP_REJET%"

for %%F in ("%TMP_REJET%") do set "SIZE=%%~zF"

if "%SIZE%"=="0" (
    echo   OK - Aucun rejet detecte
    del "%TMP_REJET%" >nul 2>&1
) else (
    echo   KO - Rejets d�tect�s
    set "HAS_ERROR=1"
)

REM =====================================================================
REM ETAPE 5 � INTEGRATION OU ARRET
REM =====================================================================
if "!HAS_ERROR!"=="1" (
    echo [ETAPE 5/5] Skip int�gration (rejets d�tect�s)
    goto ZIP
)

echo [ETAPE 5/5] Integration finale...
sqlcmd -S %Server% -d %DataBase% -E -i "%SQL_INTEG%"
if errorlevel 1 (
    echo   KO - Erreur integration finale
    set "HAS_ERROR=1"
    goto ZIP
)

echo   OK - Integration terminee

REM =====================================================================
REM REFERENTIEL + ARCHIVE SI OK
REM =====================================================================
copy "%SOURCE_DIR%\%CSV_FILE%" "%REF_DIR%\%CSV_FILE%" /Y >nul
move "%SOURCE_DIR%\%CSV_FILE%" "%ARCHIVE_DIR%\PARAM_MAPPING_V4_V5_%TS%.csv" /Y >nul

echo   OK - Archivage et r�f�rentiel mis � jour

goto ZIP

REM =====================================================================
REM ZIP FINAL (VALIDES / ERREURS)
REM =====================================================================
:ZIP

echo ZIP (VALIDES / ERREURS)...

set "ZIP_OK=%ARCHIVE_DIR%\MAPPING_VALIDES_%TS%.zip"
set "ZIP_ERR=%ARCHIVE_DIR%\MAPPING_ERREURS_%TS%.zip"

if "!HAS_ERROR!"=="0" (
    powershell Compress-Archive "%SOURCE_DIR%\%CSV_FILE%" "%ZIP_OK%" -Force
) else (
    powershell Compress-Archive "%TMP_REJET%" "%ZIP_ERR%" -Force
)

REM =====================================================================
REM Nettoyage source
REM =====================================================================
del "%SOURCE_DIR%\%CSV_FILE%" >nul 2>&1

goto FIN

REM =====================================================================
REM FIN
REM =====================================================================
:FIN

echo ================================================================
if "!HAS_ERROR!"=="0" (
    echo FIN NORMALE [%TS%]
    exit /b 0
) else (
    echo FIN AVEC ERREURS [%TS%]
    exit /b 20
)